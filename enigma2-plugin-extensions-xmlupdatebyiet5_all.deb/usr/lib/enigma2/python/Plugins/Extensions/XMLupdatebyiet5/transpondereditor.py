# -*- coding: utf-8 -*-
from __future__ import print_function, division

# Created by iet5
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.config import (
    ConfigFloat, ConfigInteger, ConfigSelection,
    ConfigText, ConfigYesNo, getConfigListEntry
)
from Components.ConfigList import ConfigListScreen

from .components import Transponder, config, _
from . import components as _components


class TransponderEditor(Screen, ConfigListScreen, Transponder):

    # FHD layout (based on old working mainfile.py) to prevent row text overlap.
    # We keep the NEW button background images (skin_default/buttons).
    skin = """        <screen position="center,center" size="1320,800" title="Edit transponder" >
            <ePixmap pixmap="skin_default/buttons/red.png" position="40,0" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/green.png" position="360,0" size="300,70" scale="stretch" alphatest="on" />

            <widget name="key_red" position="40,0" zPosition="1" size="300,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
            <widget name="key_green" position="360,0" zPosition="1" size="300,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />

            <widget name="config" position="10,125" size="1300,655" font="Regular;30" itemHeight="50"
                scrollbarMode="showOnDemand" />
        </screen>"""

    def __init__(self, session, transponderData=None):
        self.skin = TransponderEditor.skin
        Screen.__init__(self, session)
        Transponder.__init__(self, transponderData)
        self.createConfig()

        # Only RED/GREEN actions. Yellow/Blue removed as requested.
        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions'],
            {
                'cancel': self.cancel,
                'ok': self.okExit,
                'red': self.cancel,
                'green': self.okExit
            },
            -1
        )

        self['key_red'] = Button('Close')
        self['key_green'] = Button('OK')
        # Yellow/Blue keys are kept as placeholders for the layout (no actions bound).
        self['key_yellow'] = Button('')
        self['key_blue'] = Button('')

        self.list = []
        ConfigListScreen.__init__(self, self.list)
        self.transponderData = transponderData
        self.onLayoutFinish.append(self.layoutFinished)
        self.createSetup()

    def layoutFinished(self):
        if self.transponderData:
            self.setTitle('Edit transponder')
        else:
            self.setTitle('Add transponder')

        # --- Per-screen spacing fixes (do NOT share global settings) ---
        try:
            from enigma import gFont
            if hasattr(self['config'], 'l'):
                self['config'].l.setItemHeight(40)
                try:
                    self['config'].l.setFont(0, gFont('Regular', 26))
                except TypeError:
                    try:
                        self['config'].l.setFont(gFont('Regular', 26))
                    except Exception:
                        pass
        except Exception:
            pass


    def createConfig(self):
        self.configTransponderSystem = ConfigSelection([('DVB-S', 'DVB-S'), ('DVB-S2', 'DVB-S2')], self.system)
        self.configTransponderFrequency = ConfigFloat(
            default=[int(float(self.frequency)) // 1000, int(float(self.frequency)) % 1000],
            limits=[(0, 99999), (0, 999)]
        )
        self.configTransponderPolarisation = ConfigSelection(
            [('H', 'horizontal'), ('V', 'vertical'), ('L', 'circular left'), ('R', 'circular right')],
            self.polarisation
        )
        self.configTransponderSymbolrate = ConfigInteger(default=int(float(self.symbolrate)) // 1000, limits=(0, 99999))

        self.configTransponderFec = ConfigSelection(
            [('FEC_AUTO', 'Auto'),
             ('FEC_1_2', '1/2'),
             ('FEC_2_3', '2/3'),
             ('FEC_3_4', '3/4'),
             ('FEC_5_6', '5/6'),
             ('FEC_6_7', '6/7'),
             ('FEC_7_8', '7/8')],
            self.fec
        )
        self.configTransponderFec2 = ConfigSelection(
            [('FEC_AUTO', 'Auto'),
             ('FEC_1_2', '1/2'),
             ('FEC_2_3', '2/3'),
             ('FEC_3_4', '3/4'),
             ('FEC_5_6', '5/6'),
             ('FEC_6_7', '6/7'),
             ('FEC_7_8', '7/8'),
             ('FEC_8_9', '8/9'),
             ('FEC_3_5', '3/5'),
             ('FEC_4_5', '4/5'),
             ('FEC_9_10', '9/10')],
            self.fec
        )

        self.configTransponderInversion = ConfigSelection([('OFF', 'off'), ('ON', 'on'), ('AUTO', 'auto')], self.inversion)
        self.configTransponderModulation = ConfigSelection(
            [('AUTO', 'auto'),
             ('QPSK', 'QPSK'),
             ('8PSK', '8PSK'),
             ('QAM16', 'QAM16'),
             ('16APSK', '16APSK'),
             ('32APSK', '32APSK')],
            self.modulation
        )
        self.configTransponderRollOff = ConfigSelection([('0_35', '0.35'), ('0_25', '0.25'), ('0_20', '0.20'), ('Auto', 'Auto')], self.rolloff)
        self.configTransponderPilot = ConfigSelection([('OFF', 'off'), ('ON', 'on'), ('AUTO', 'auto')], self.pilot)

        self.configTransponderUseMultistream = ConfigYesNo(default=self.UseMultistream)
        self.configTransponderIsId = ConfigInteger(default=int(float(self.isid)), limits=(0, 255))
        self.configTransponderPlsMode = ConfigSelection([('Root', 'Root'), ('Gold', 'Gold'), ('Combo', 'Combo')], self.plsmode)
        self.configTransponderPlsCode = ConfigInteger(default=int(float(self.plscode)), limits=(0, 262142))

        self.configTransponderUseTsid = ConfigYesNo(default=self.useTsid)
        self.configTransponderUseOnid = ConfigYesNo(default=self.useOnid)
        self.configTransponderTsid = ConfigInteger(default=int(float(self.tsid)), limits=(0, 65535))
        self.configTransponderOnid = ConfigInteger(default=int(float(self.onid)), limits=(0, 65535))

        self.configTransponderUseT2MI = ConfigYesNo(default=self.UseT2MI)
        self.configTransponderT2miPlpId = ConfigInteger(default=int(float(self.t2mi_plp_id)), limits=(0, 255))
        self.configTransponderT2miPid = ConfigInteger(default=int(float(self.t2mi_pid)), limits=(0, 8191))

    def createSetup(self):
        self.list = []

        self.list.append(getConfigListEntry('System', self.configTransponderSystem))

        if self.system == 'DVB-S' or self.system == 'DVB-S2':
            self.list.append(getConfigListEntry('Frequency', self.configTransponderFrequency))
            self.list.append(getConfigListEntry('Polarization', self.configTransponderPolarisation))
            self.list.append(getConfigListEntry('Symbolrate', self.configTransponderSymbolrate))

        if self.system == 'DVB-S':
            self.list.append(getConfigListEntry('FEC', self.configTransponderFec))
        elif self.system == 'DVB-S2':
            self.list.append(getConfigListEntry('FEC', self.configTransponderFec2))

        if self.system == 'DVB-S' or self.system == 'DVB-S2':
            self.list.append(getConfigListEntry('Inversion', self.configTransponderInversion))

        if self.system == 'DVB-S2':
            self.list.append(getConfigListEntry('Modulation', self.configTransponderModulation))
            self.list.append(getConfigListEntry('RollOff', self.configTransponderRollOff))
            self.list.append(getConfigListEntry('Pilot', self.configTransponderPilot))

        if self.system == 'DVB-S' or self.system == 'DVB-S2':
            if self.system == 'DVB-S2':
                self.list.append(getConfigListEntry('Use multistream', self.configTransponderUseMultistream))
                if self.UseMultistream:
                    self.list.append(getConfigListEntry('Input Stream ID', self.configTransponderIsId))
                    self.list.append(getConfigListEntry('PLS Mode', self.configTransponderPlsMode))
                    self.list.append(getConfigListEntry('PLS Code', self.configTransponderPlsCode))

            if config.misc.tssateditorT2MI.value:
                if self.system == 'DVB-S2':
                    self.list.append(getConfigListEntry('Use T2MI PLP', self.configTransponderUseT2MI))
                    if self.UseT2MI:
                        self.list.append(getConfigListEntry('T2MI PLP ID', self.configTransponderT2miPlpId))
                        self.list.append(getConfigListEntry('T2MI PID', self.configTransponderT2miPid))
            else:
                self.list.append(getConfigListEntry('Use tsid', self.configTransponderUseTsid))
                if self.useTsid:
                    self.list.append(getConfigListEntry('TSID', self.configTransponderTsid))

                self.list.append(getConfigListEntry('Use onid', self.configTransponderUseOnid))
                if self.useOnid:
                    self.list.append(getConfigListEntry('ONID', self.configTransponderOnid))

        self['config'].list = self.list
        self['config'].l.setList(self.list)

    def cancel(self):
        self.close(None)

    def okExit(self):
        _components.need_update = True

        self.system = self.configTransponderSystem.value
        self.frequency = self.configTransponderFrequency.value
        self.polarisation = self.configTransponderPolarisation.value
        self.symbolrate = self.configTransponderSymbolrate.value * 1000

        if self.system == 'DVB-S':
            self.fec = self.configTransponderFec.value
        else:
            self.fec = self.configTransponderFec2.value

        self.inversion = self.configTransponderInversion.value

        # These are only meaningful on DVB-S2; keep as original behavior
        try:
            self.modulation = self.configTransponderModulation.value
        except Exception:
            pass
        try:
            self.rolloff = self.configTransponderRollOff.value
        except Exception:
            pass
        try:
            self.pilot = self.configTransponderPilot.value
        except Exception:
            pass

        self.isid = self.configTransponderIsId.value
        self.plsmode = self.configTransponderPlsMode.value
        self.plscode = self.configTransponderPlsCode.value
        self.t2mi_plp_id = self.configTransponderT2miPlpId.value
        self.t2mi_pid = self.configTransponderT2miPid.value
        self.tsid = self.configTransponderTsid.value
        self.onid = self.configTransponderOnid.value

        self.close(self.exportAll())

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.newConfig()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.newConfig()

    def newConfig(self):
        checkList = (
            self.configTransponderSystem,
            self.configTransponderUseTsid,
            self.configTransponderUseOnid,
            self.configTransponderUseMultistream,
            self.configTransponderUseT2MI
        )
        for x in checkList:
            if self['config'].getCurrent()[1] == x:
                if x == self.configTransponderSystem:
                    self.system = self.configTransponderSystem.value
                elif x == self.configTransponderUseMultistream:
                    self.UseMultistream = self.configTransponderUseMultistream.value
                elif x == self.configTransponderUseT2MI:
                    self.UseT2MI = self.configTransponderUseT2MI.value
                elif x == self.configTransponderUseTsid:
                    self.useTsid = self.configTransponderUseTsid.value
                elif x == self.configTransponderUseOnid:
                    self.useOnid = self.configTransponderUseOnid.value
            self.createSetup()