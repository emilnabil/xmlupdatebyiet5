# -*- coding: utf-8 -*-
from __future__ import print_function, division

# Created by iet5
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Tools import Notifications
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.MenuList import MenuList
from Components.Label import Label

# Some images differ in enigma imports (Python2/3 + different distros)
try:
    from enigma import eRect, eTimer
except Exception:
    eRect = None
    from enigma import eTimer

from .components import TransponderList, Head, Transponder, config, FHD_Res, HD_Res, _
from . import components as _components
from .transpondereditor import TransponderEditor


def mbText(txt):
    """MessageBox text compatible with DreamOS (Py2 bytes) and OpenATV (Py3 str)."""
    if txt is None:
        txt = ""
    # Python 2: return bytes/str, never unicode
    try:
        unicode_type = unicode  # noqa: F821
        if isinstance(txt, unicode_type):
            return txt.encode("utf-8")
        # ensure str
        return str(txt)
    except Exception:
        pass
    # Python 3: return str, decode bytes if needed
    try:
        if isinstance(txt, (bytes, bytearray)):
            return txt.decode("utf-8", "ignore")
    except Exception:
        pass
    try:
        return str(txt)
    except Exception:
        return ""


class TranspondersEditor(Screen):

    def _safeSetSelectionClip(self, listbox, rect):
        """Compatibility: some images accept (rect, True), others accept (rect) only."""
        if rect is None:
            return
        try:
            listbox.setSelectionClip(rect, True)
        except TypeError:
            try:
                listbox.setSelectionClip(rect)
            except Exception:
                pass

    def _dbg(self, msg):
        try:
            f = open('/tmp/XMLupdatebyiet5_transponders_debug.log', 'a')
            f.write(str(msg) + '\n')
            f.close()
        except Exception:
            pass

    def _ui(self, s):
        """
        DreamOS/Merlin strict UI string:
        Always return UTF-8 BYTES (std::string) for any Enigma2 UI call:
        - eLabel_setText
        - eWindow_setTitle
        - MessageBox text
        Works on Python 2.7 and Python 3.x.
        """
        if s is None:
            return b''

        # Python 2 unicode type detection
        try:
            unicode_type = unicode  # noqa: F821
        except Exception:
            unicode_type = None

        # If already bytes
        try:
            if isinstance(s, bytes):
                return s
        except Exception:
            pass

        # Python 2: unicode -> utf-8 bytes
        if unicode_type is not None:
            try:
                if isinstance(s, unicode_type):
                    return s.encode('utf-8', 'ignore')
            except Exception:
                pass

        # Python 3: str -> utf-8 bytes
        try:
            return str(s).encode('utf-8', 'ignore')
        except Exception:
            try:
                return ('%s' % s).encode('utf-8', 'ignore')
            except Exception:
                return b''

    def _startConfirm(self, mode, timeout_sec=6):
        """
        mode: 'delete'
        DreamOS-safe confirmation without MessageBox (prevents input freeze).
        """
        self._confirm_mode = mode
        try:
            self._confirm_timer.stop()
        except Exception:
            pass

        if mode == 'delete':
            # English message (per request)
            try:
                self['confirm'].setText(self._ui('Confirm delete: GREEN=Yes  RED/EXIT=No'))
            except Exception:
                pass
        else:
            try:
                self['confirm'].setText(self._ui(''))
            except Exception:
                pass

        # Start timer (DreamOS variants)
        try:
            self._confirm_timer.startLongTimer(int(timeout_sec))
        except Exception:
            try:
                self._confirm_timer.start(int(timeout_sec * 1000), True)
            except Exception:
                pass

    def _clearConfirm(self):
        self._confirm_mode = None
        try:
            self._confirm_timer.stop()
        except Exception:
            pass
        try:
            self['confirm'].setText(self._ui(''))
        except Exception:
            pass

    def _onConfirmTimeout(self):
        self._clearConfirm()

    # --- FIX DreamOS highlight flicker: re-apply selection clip repeatedly after list redraw ---
    def _kickSelectionRefresh(self):
        """
        DreamOS redraws list multiple times while moving.
        Re-apply selection clip repeatedly for a short time to prevent flicker/disappear.
        """
        self._sel_refresh_left = 10  # 10 * 50ms = 500ms
        try:
            self._sel_timer.stop()
        except Exception:
            pass
        try:
            # repeat timer
            self._sel_timer.start(50, False)
        except Exception:
            try:
                self._sel_timer.start(50)
            except Exception:
                pass

    def _applySelectionLater(self):
        try:
            self.updateSelection()
        except Exception:
            pass

        try:
            self._sel_refresh_left -= 1
        except Exception:
            self._sel_refresh_left = 0

        if self._sel_refresh_left <= 0:
            try:
                self._sel_timer.stop()
            except Exception:
                pass

    # FHD only (1320x800).
    skin = """        <screen position="center,center" size="1320,800" title="Transponders Editor" >
            <ePixmap pixmap="skin_default/buttons/red.png" position="40,0" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/green.png" position="360,0" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/yellow.png" position="680,0" size="280,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/blue.png" position="970,0" size="280,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/ok.png" position="1275,5" size="35,35" alphatest="on" />

            <widget name="key_red" position="40,0" zPosition="1" size="300,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
            <widget name="key_green" position="360,0" zPosition="1" size="300,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
            <widget name="key_yellow" position="680,0" zPosition="1" size="280,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#a08500" transparent="1" />
            <widget name="key_blue" position="970,0" zPosition="1" size="280,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#003366" transparent="1" />

            <widget name="head" position="10,80" size="1300,40" scrollbarMode="showNever" />
            <widget name="list" position="10,125" size="1300,490" scrollbarMode="showOnDemand" />

            <widget name="confirm" position="10,615" size="1300,40" font="Regular;28"
                halign="center" valign="center" transparent="1" />
        </screen>"""

    def __init__(self, session, satellite=None):
        self.skin = TranspondersEditor.skin
        Screen.__init__(self, session)

        # Timers MUST exist (otherwise screen may crash on first move/layout)
        self._sel_timer = eTimer()
        try:
            self._sel_timer.callback.append(self._applySelectionLater)
        except Exception:
            try:
                self._sel_timer.timeout.get().append(self._applySelectionLater)
            except Exception:
                pass

        self._confirm_timer = eTimer()
        try:
            self._confirm_timer.callback.append(self._onConfirmTimeout)
        except Exception:
            try:
                self._confirm_timer.timeout.get().append(self._onConfirmTimeout)
            except Exception:
                pass

        self._confirm_mode = None
        self._sel_refresh_left = 0

        self._changed = False

        self['actions'] = ActionMap(
            ['SatellitesEditorActions'],
            {
                'nextPage': self.nextPage,
                'prevPage': self.prevPage,
                'select': self.editTransponder,
                'exit': self.exitConfirm,
                'left': self.left,
                'leftUp': self.doNothing,
                'leftRepeated': self.doNothing,
                'right': self.right,
                'rightUp': self.doNothing,
                'rightRepeated': self.doNothing,
                'up': self.up,
                'upUp': self.upUp,
                'upRepeated': self.upRepeated,
                'down': self.down,
                'downUp': self.downUp,
                'downRepeated': self.downRepeated,
                # RED = Remove (delete)
                'red': self.removeTransponder,
                # GREEN = Edit
                'green': self.editTransponder,
                # YELLOW = Add
                'yellow': self.addTransponder,
                # BLUE = Sort
                'blue': self.sortColumn
            },
            -1
        )

        self.transponderslist = satellite[1]
        self.satelliteName = satellite[0].get('name')

        # Button labels MUST match actions (English only)
        self['key_red'] = Button(_('Remove'))
        self['key_green'] = Button(_('Edit'))
        self['key_yellow'] = Button(_('Add'))
        self['key_blue'] = Button(_('Sort'))

        # Confirmation label (safe even if not used)
        self['confirm'] = Label('')

        self['head'] = Head()
        self.currentSelectedColumn = 0
        self['list'] = TransponderList()
        self['list'].setEntries(self.transponderslist)
        self.onLayoutFinish.append(self.layoutFinished)

        if not config.misc.tssateditorT2MI.value:
            self.row = [
                ['System', '1', False],
                ['Freq.', '2', False],
                ['Pol.', '3', False],
                ['SR', '4', False],
                ['FEC', '5', False],
                ['Modul.', '6', False],
                ['Rolloff', '7', False],
                ['Invers.', '8', False],
                ['Pilot', '9', False],
                ['IS ID', '10', False],
                ['PLS Mode', '11', False],
                ['PLS Code', '12', False],
                ['TSID', '13', False],
                ['ONID', '14', False]
            ]
        else:
            self.row = [
                ['System', '1', False],
                ['Freq.', '2', False],
                ['Pol.', '3', False],
                ['SR', '4', False],
                ['FEC', '5', False],
                ['Modul.', '6', False],
                ['Rolloff', '7', False],
                ['Invers.', '8', False],
                ['Pilot', '9', False],
                ['IS ID', '10', False],
                ['PLS Mode', '11', False],
                ['PLS Code', '12', False],
                ['T2MI ID', '13', False],
                ['T2MI PID', '14', False]
            ]

    def layoutFinished(self):
        try:
            # --- Per-screen spacing fixes (do NOT share global settings) ---
            # Some OpenATV-based skins render list rows too close together.
            # Apply the old working values to prevent text overlap.
            try:
                from enigma import gFont
                if hasattr(self['list'], 'l'):
                    # Old values: itemHeight=40, fonts 27/23
                    try:
                        self['list'].l.setItemHeight(40)
                    except Exception:
                        pass
                    try:
                        self['list'].l.setFont(0, gFont('Regular', 27))
                        self['list'].l.setFont(1, gFont('Regular', 23))
                    except Exception:
                        pass

                if hasattr(self['head'], 'l'):
                    try:
                        self['head'].l.setItemHeight(40)
                    except Exception:
                        pass
                    try:
                        self['head'].l.setFont(0, gFont('Regular', 23))
                    except Exception:
                        pass
            except Exception:
                pass

            try:
                sat = self.satelliteName
                if sat is None:
                    sat = ''
                title = _('Transponders Editor (%s)') % sat
                # setTitle usually accepts str in many images; DreamOS strict wants bytes
                try:
                    self.setTitle(self._ui(title))
                except Exception:
                    self.setTitle(title)
            except Exception as e:
                self._dbg('setTitle failed: %s' % e)

            row = self['list'].getCurrent()
            if row is None:
                self._dbg('layoutFinished: no current row')
                return

            head = []
            for x in range(1, len(row)):
                try:
                    head.append((row[x][1], row[x][3], self.row[x - 1][0]))
                except Exception as e:
                    self._dbg('head build failed at %s: %s' % (x, e))

            try:
                self['head'].setEntries(head)
            except Exception as e:
                self._dbg('head setEntries failed: %s' % e)
                return

            if eRect is not None:
                try:
                    data = self['head'].l.getCurrentSelection()
                    if data is None:
                        self._dbg('head current selection is None')
                        return

                    idx = self.currentSelectedColumn + 1
                    if idx < 0 or idx >= len(data):
                        self._dbg('selection index out of range: %s len=%s' % (idx, len(data)))
                        return

                    d = data[idx]
                    self._safeSetSelectionClip(self['head'].l, eRect(d[1], d[0], d[3], d[4]))
                except Exception as e:
                    self._dbg('selectionClip failed: %s' % e)

            try:
                self.updateSelection()
                self._kickSelectionRefresh()
            except Exception as e:
                self._dbg('updateSelection failed: %s' % e)

        except Exception as e:
            self._dbg('layoutFinished fatal: %s' % e)
            return

    def updateSelection(self):
        if eRect is None:
            return

        row = self['list'].l.getCurrentSelection()
        if row is None:
            return
        if len(row) < 2:
            return

        firstColumn = row[1]
        lastColumn = row[len(row) - 1]

        # Fix DreamOS: width must be width, not X2 coordinate
        x = firstColumn[1]
        y = firstColumn[0]
        w = (lastColumn[1] + lastColumn[3]) - x
        h = lastColumn[4]
        if w < 1:
            w = 1
        if h < 1:
            h = 1

        self._safeSetSelectionClip(self['list'].l, eRect(x, y, w, h))

    def doNothing(self):
        pass

    def left(self):
        self._clearConfirm()
        if self.currentSelectedColumn:
            self.currentSelectedColumn -= 1
            data = self['head'].l.getCurrentSelection()
            data = data[self.currentSelectedColumn + 1]
            if eRect is not None:
                self._safeSetSelectionClip(self['head'].l, eRect(data[1], data[0], data[3], data[4]))
        self._kickSelectionRefresh()

    def right(self):
        self._clearConfirm()
        if self.currentSelectedColumn < len(self.row) - 1:
            self.currentSelectedColumn += 1
            data = self['head'].l.getCurrentSelection()
            data = data[self.currentSelectedColumn + 1]
            if eRect is not None:
                self._safeSetSelectionClip(self['head'].l, eRect(data[1], data[0], data[3], data[4]))
        self._kickSelectionRefresh()

    def upRepeated(self):
        self._clearConfirm()
        self['list'].up()
        self.updateSelection()
        self._kickSelectionRefresh()

    def downRepeated(self):
        self._clearConfirm()
        self['list'].down()
        self.updateSelection()
        self._kickSelectionRefresh()

    def nextPage(self):
        self._clearConfirm()
        self['list'].pageUp()
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None:
            self.lastSelectedIndex = cur_idx
            self.updateSelection()
            self._kickSelectionRefresh()

    def prevPage(self):
        self._clearConfirm()
        self['list'].pageDown()
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None:
            self.lastSelectedIndex = cur_idx
            self.updateSelection()
            self._kickSelectionRefresh()

    def up(self):
        self._clearConfirm()
        self['list'].up()
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None:
            self.lastSelectedIndex = cur_idx
            self.updateSelection()
            self._kickSelectionRefresh()

    def down(self):
        self._clearConfirm()
        self['list'].down()
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None:
            self.lastSelectedIndex = cur_idx
            self.updateSelection()
            self._kickSelectionRefresh()

    def upUp(self):
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None and getattr(self, 'lastSelectedIndex', None) != cur_idx:
            self.lastSelectedIndex = cur_idx

    def downUp(self):
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None and getattr(self, 'lastSelectedIndex', None) != cur_idx:
            self.lastSelectedIndex = cur_idx

    def addTransponder(self):
        self._clearConfirm()
        self.session.openWithCallback(self.finishedTransponderAdd, TransponderEditor)

    def editTransponder(self):
        self._clearConfirm()
        if not len(self.transponderslist):
            return
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None:
            self.session.openWithCallback(
                self.finishedTransponderEdit,
                TransponderEditor,
                self.transponderslist[cur_idx]
            )

    def finishedTransponderEdit(self, result):
        if result is None:
            return
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None:
            return
        _components.need_update = True
        self._changed = True

        self.transponderslist[cur_idx] = result
        self['list'].setEntries(self.transponderslist)

    def finishedTransponderAdd(self, result):
        if result is None:
            return
        try:
            self.transponderslist.append(result)
        except Exception:
            return
        _components.need_update = True
        self._changed = True

        self['list'].setEntries(self.transponderslist)

    def removeTransponder(self):
        if len(self.transponderslist):
            cb_func = lambda ret: (not ret) or self.deleteTransponder()
            self.session.openWithCallback(
                cb_func,
                MessageBox,
                _('Remove transponder?'),
                MessageBox.TYPE_YESNO
            )

    def deleteTransponder(self):
        if len(self.transponderslist):
            cur_idx = self['list'].getSelectedIndex()
            if cur_idx is None:
                return
            _components.need_update = True
            self._changed = True
            self.transponderslist.pop(cur_idx)
            self['list'].setEntries(self.transponderslist)

    def _exitCallback(self, ret):
        # YES -> return updated list to caller (will be saved by main screen)
        if ret:
            self.close(self.transponderslist)
        else:
            # NO -> discard changes
            self.close(None)

    def exitConfirm(self):
        # If nothing changed, just return current list
        if not getattr(self, '_changed', False):
            self.close(self.transponderslist)
            return

        # English only (per request)
        self.session.openWithCallback(
            self._exitCallback,
            MessageBox,
            mbText('Save changes?'),
            MessageBox.TYPE_YESNO,
            default=True
        )

    def cancel(self):
        self.exitConfirm()

    def compareColumn(self, a):
        if config.misc.tssateditorT2MI.value:
            map = {
                'System': 'system',
                'Freq.': 'frequency',
                'Pol.': 'polarization',
                'SR': 'symbol_rate',
                'FEC': 'fec_inner',
                'Modul.': 'modulation',
                'Rolloff': 'rolloff',
                'Invers.': 'inversion',
                'Pilot': 'pilot',
                'IS ID': 'is_id',
                'PLS Mode': 'pls_mode',
                'PLS Code': 'pls_code',
                'T2MI ID': 't2mi_plp_id',
                'T2MI PID': 't2mi_pid'
            }
        else:
            map = {
                'System': 'system',
                'Freq.': 'frequency',
                'Pol.': 'polarization',
                'SR': 'symbol_rate',
                'FEC': 'fec_inner',
                'Modul.': 'modulation',
                'Rolloff': 'rolloff',
                'Invers.': 'inversion',
                'Pilot': 'pilot',
                'IS ID': 'is_id',
                'PLS Mode': 'pls_mode',
                'PLS Code': 'pls_code',
                'TSID': 'tsid',
                'ONID': 'onid'
            }
        cur = map[self.row[self.currentSelectedColumn][0]]
        return int(float(a.get(cur, '-1')))

    def sortColumn(self):
        rev = self.row[self.currentSelectedColumn][2]
        self.transponderslist.sort(key=self.compareColumn, reverse=rev)
        self.row[self.currentSelectedColumn][2] = (not rev)
        self['list'].setEntries(self.transponderslist)
        _components.need_update = True
        self._changed = True