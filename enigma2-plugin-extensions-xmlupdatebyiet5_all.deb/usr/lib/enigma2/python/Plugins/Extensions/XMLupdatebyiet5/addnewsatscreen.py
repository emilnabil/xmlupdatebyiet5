# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

# Created by iet5
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label

from .sateditscreen import SatEditor


class AddNewSatScreen(Screen):
    # FHD only (1320x800).
    skin = """        <screen name="AddNewSatScreen" position="center,center" size="1320,800" title="Add new satellite" >
            <ePixmap pixmap="skin_default/buttons/red.png" position="40,0" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/green.png" position="360,0" size="300,70" scale="stretch" alphatest="on" />

            <widget name="key_red" position="40,0" zPosition="1" size="300,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
            <widget name="key_green" position="360,0" zPosition="1" size="300,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />

            <widget name="status" position="10,80" size="1300,40" font="Regular;30" halign="center" valign="center" transparent="1" />
            <widget name="satname" position="10,125" size="1300,40" font="Regular;32" halign="left" />
            <widget name="poslabel" position="10,180" size="900,40" font="Regular;30" halign="left" />
            <widget name="posvalue" position="930,180" size="380,40" font="Regular;30" halign="right" />
            <widget name="hint" position="10,700" size="1300,80" font="Regular;28" halign="center" valign="center" foregroundColor="#f0f0f0" transparent="1" />
        </screen>"""

    def __init__(self, session, satelliteslist=None):
        Screen.__init__(self, session)
        self.session = session
        self.satelliteslist = satelliteslist

        self["title_left"] = Label("Add New Satellite")
        self["title_right"] = Label("")

        self["key_red"] = Label("Back")
        self["key_green"] = Label("Add")

        self["actions"] = ActionMap(
            ["ColorActions", "OkCancelActions"],
            {
                "red": self.close,
                "green": self.add_satellite,
                "ok": self.add_satellite,
                "cancel": self.close,
            },
            -1
        )

    def add_satellite(self):
        # Open the satellite editor in add mode
        self.session.openWithCallback(self.satellite_added, SatEditor, self.satelliteslist)

    def satellite_added(self, result):
        # SatEditor handles validation and shows the 10-second warning before blocking save.
        # If save succeeds, result is a dict and we close this screen.
        if result:
            self.close()