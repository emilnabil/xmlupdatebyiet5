# -*- coding: utf-8 -*-
from __future__ import print_function, division, absolute_import

import os
import sys
from Components.config import config, ConfigYesNo
from enigma import getDesktop

from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import (
    eListboxPythonMultiContent, eListbox, gFont,
    RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER,
    RT_VALIGN_CENTER, RT_VALIGN_TOP
)

# eRect is used for selection clipping in some listbox helpers
from enigma import eRect

# HTMLComponent (some images may not ship it; keep plugin running)
try:
    from Components.HTMLComponent import HTMLComponent
except Exception:
    HTMLComponent = object

# GUIComponent (required by some helper widgets)
try:
    from Components.GUIComponent import GUIComponent
except Exception:
    GUIComponent = object



PY3 = sys.version_info[0] == 3


# --- Text compatibility between Python 2.7 and Python 3.x / Enigma2 ---
try:
    unicode  # Python 2
except NameError:  # Python 3
    unicode = str

def safe_text(val):
    """Return a type that Enigma2 list renderers accept (py2: str/bytes, py3: str)."""
    if val is None:
        return '' if PY3 else ''
    try:
        if PY3:
            if isinstance(val, bytes):
                return val.decode('utf-8', 'ignore')
            return str(val)
        else:
            # Python 2: Enigma2 SWIG often expects 'str' (bytes), not 'unicode'
            if isinstance(val, unicode):
                return val.encode('utf-8', 'ignore')
            return str(val)
    except Exception:
        try:
            return str(val)
        except Exception:
            return '' if PY3 else ''

# Initialize config if not already done
try:
    config.misc.tssateditorT2MI
except:
    config.misc.tssateditorT2MI = ConfigYesNo(False)

# --------- Version from file ---------
version_file_path = "/usr/lib/enigma2/python/Plugins/SystemPlugins/TSsatEditor/version.txt"
try:
    with open(version_file_path, "r") as f:
        currversion = f.read().strip()
except Exception:
    currversion = "Unknown"

need_update = False

FHD_Res = False
HD_Res = False
sz_y = getDesktop(0).size().height()
if sz_y >= 1080:
    FHD_Res = True
elif sz_y >= 720 and sz_y <= 1079:
    HD_Res = True

# Import translation function
try:
    from . import _
except ImportError:
    _ = lambda x: x


config.misc.tssateditorT2MI = ConfigYesNo(False)

class Transponder():
    essential = ['frequency', 'polarization', 'symbol_rate']
    niceToHave = ['system',
     'fec_inner',
     'is_id',
     'pls_code',
     't2mi_plp_id',
     't2mi_pid',
     'tsid',
     'onid']
    transSystem = {'0': 'DVB-S',
     '1': 'DVB-S2',
     'dvb-s': 'DVB-S',
     'dvb-s2': 'DVB-S2'}
    reTransSystem = {'DVB-S': '0',
     'DVB-S2': '1'}
    transPolarisation = {'0': 'H',
     'h': 'H',
     '1': 'V',
     'v': 'V',
     '2': 'L',
     'cl': 'L',
     'l': 'L',
     '3': 'R',
     'cr': 'R',
     'r': 'R',
     'i': 'i'}
    reTransPolarisation = {'H': '0',
     'V': '1',
     'L': '2',
     'R': '3'}
    transModulation = {'0': 'AUTO',
     '1': 'QPSK',
     '2': '8PSK',
     '3': 'QAM16',
     '4': '16APSK',
     '5': '32APSK'}
    reTransModulation = {'AUTO': '0',
     'QPSK': '1',
     '8PSK': '2',
     'QAM16': '3',
     '16APSK': '4',
     '32APSK': '5'}
    transRolloff = {'0': '0_35',
     '1': '0_25',
     '2': '0_20',
     '3': 'Auto'}
    reTransRolloff = {'0_35': '0',
     '0_25': '1',
     '0_20': '2',
     'Auto': '3'}
    transOnOff = {'0': 'OFF',
     '1': 'ON',
     '2': 'AUTO'}
    reTransOnOff = {'OFF': '0',
     'ON': '1',
     'AUTO': '2'}
    transFec = {'0': 'FEC_AUTO',
     '1': 'FEC_1_2',
     '2': 'FEC_2_3',
     '3': 'FEC_3_4',
     '4': 'FEC_5_6',
     '5': 'FEC_7_8',
     '6': 'FEC_8_9',
     '7': 'FEC_3_5',
     '8': 'FEC_4_5',
     '9': 'FEC_9_10',
     '10': 'FEC_6_7',
     '15': 'FEC_NONE',
     'Auto': 'FEC_AUTO',
     '1/2': 'FEC_1_2',
     '2/3': 'FEC_2_3',
     '3/4': 'FEC_3_4',
     '5/6': 'FEC_5_6',
     '6/7': 'FEC_6_7',
     '7/8': 'FEC_7_8',
     '8/9': 'FEC_8_9',
     '3/5': 'FEC_3_5',
     '4/5': 'FEC_4_5',
     '9/10': 'FEC_9_10',
     'none': 'FEC_NONE'}
    reTransFec = {'FEC_AUTO': '0',
     'FEC_1_2': '1',
     'FEC_2_3': '2',
     'FEC_3_4': '3',
     'FEC_5_6': '4',
     'FEC_7_8': '5',
     'FEC_8_9': '6',
     'FEC_3_5': '7',
     'FEC_4_5': '8',
     'FEC_9_10': '9',
     'FEC_6_7': '10',
     'FEC_NONE': '15'}
    onlyDVBS2Fec = ['FEC_8_9',
     'FEC_3_5',
     'FEC_4_5',
     'FEC_9_10']
    transBand = {'KU': ('10700000', '12750000'),
     'C': ('3400000', '4200000')}
    transPlsMode = {'0': 'Root',
     '1': 'Gold',
     '2': 'Combo',
     '3': 'Unknown'}
    reTransPlsMode = {'Root': '0',
     'Gold': '1',
     'Combo': '2',
     'Unknown': '3'}

    def __init__(self, transponder):
        self.rawData = transponder
        self.system = 'DVB-S'
        self.__frequency = '10700000'
        self.__symbolrate = '27500000'
        self.polarisation = 'H'
        self.modulation = 'QPSK'
        self.pilot = 'OFF'
        self.rolloff = '0_35'
        self.fec = 'FEC_AUTO'
        self.inversion = 'AUTO'
        self.__isid = "0"
        self.plsmode = 'Root'
        self.__plscode = '1'
        self.UseMultistream = False
        self.UseT2MI = False
        self.__t2mi_plp_id = '0'
        self.__t2mi_pid = '4096'
        self.__tsid = '0'
        self.useTsid = False
        self.__onid = '0'
        self.useOnid = False
        self.band = 'KU'
        self.__importColor = None
        self.transponderDoctor(self.rawData)

    def transponderDoctor(self, transponder):
        if not isinstance(transponder, dict):
            print('transponderDoctor: Transponderdaten muessen vom Type DICT sein')
            print(transponder)
            return
        param = transponder.keys()
        transParam = {}
        for x in param:
            transParam[x] = x.lower()

        if 'polarisation' in transParam:
            transParam.update({'polarization': transParam.get('polarisation').lower()})
            del transParam['polarisation']
        missing = []
        for x in self.essential:
            if x not in transParam:
                missing.append(x)

        if len(missing):
            print('transponderDoctor: Folgende Parameter fehlen:', missing)
            return
        self.polarisation = self.transPolarisation.get(transponder.get(transParam.get('polarization'), 'i').lower())
        if self.polarisation == 'i':
            print('transponderDoctor: unbekannter Wert fuer Polarisation (%s)' % transParam.get('polarization'))
            return
        self.__frequency = transponder.get(transParam.get('frequency'), 'i').lower()
        self.__symbolrate = transponder.get(transParam.get('symbol_rate'), 'i').lower()
        dvb_s_cnt = 0
        dvb_s2_cnt = 0
        self.__importColor = transponder.get('import', None)
        if 'system' in transParam:
            self.system = self.transSystem.get(transponder.get(transParam.get('system'), 'i').lower())
            if self.system == 'DVB-S':
                dvb_s_cnt += 1
            if self.system == 'DVB-S2':
                dvb_s2_cnt += 1
        if 'modulation' in transParam:
            self.modulation = self.transModulation.get(transponder.get(transParam.get('modulation'), 'i').lower())
            if self.modulation == '8PSK' or self.modulation == 'QAM16':
                dvb_s2_cnt += 1
        if 'pilot' in transParam:
            self.pilot = self.transOnOff.get(transponder.get(transParam.get('pilot'), 'i').lower())
            if self.pilot == 'ON' or self.pilot == 'AUTO':
                dvb_s2_cnt += 1
        if 'rolloff' in transParam:
            self.rolloff = self.transRolloff.get(transponder.get(transParam.get('rolloff'), 'i').lower())
            if self.rolloff == '0_25':
                dvb_s2_cnt += 1
        if 'fec_inner' in transParam:
            self.fec = self.transFec.get(transponder.get(transParam.get('fec_inner'), 'i').lower())
            if self.fec in self.onlyDVBS2Fec:
                dvb_s2_cnt += 1
        if dvb_s2_cnt:
            self.system = 'DVB-S2'
        else:
            self.system = 'DVB-S'
        if 'inversion' in transParam:
            self.inversion = self.transOnOff.get(transponder.get(transParam.get('inversion'), 'i').lower())
        if 'is_id' in transParam:
            self.__isid = transponder.get(transParam.get('is_id'), 'i').lower()
            self.UseMultistream = True
        if 'pls_mode' in transParam:
            self.plsmode = self.transPlsMode.get(transponder.get(transParam.get('pls_mode'), 'i').lower())
            self.UseMultistream = True
        if 'pls_code' in transParam:
            self.__plscode = transponder.get(transParam.get('pls_code'), 'i').lower()
            self.UseMultistream = True
        if 't2mi_plp_id' in transParam:
            self.__t2mi_plp_id = transponder.get(transParam.get('t2mi_plp_id'), 'i').lower()
            self.UseT2MI = True
        if 't2mi_pid' in transParam:
            self.__t2mi_pid = transponder.get(transParam.get('t2mi_pid'), 'i').lower()
            self.UseT2MI = True
        if 'tsid' in transParam:
            self.__tsid = transponder.get(transParam.get('tsid'), 'i').lower()
            self.useTsid = True
        if 'onid' in transParam:
            self.__onid = transponder.get(transParam.get('onid'), 'i').lower()
            self.useOnid = True

    def getFrequency(self):
        return self.__frequency

    def setFrequency(self, frequency):
        if isinstance(frequency, list):
            if len(frequency) == 2:
                if isinstance(frequency[0], int) and isinstance(frequency[1], int):
                    self.__frequency = str(frequency[0] * 1000 + frequency[1])
                    return
        else:
            self.__frequency = str(frequency)

    frequency = property(getFrequency, setFrequency)
    importColor = property(lambda self: self.__importColor)

    def getSymbolrate(self):
        return self.__symbolrate

    def setSymbolrate(self, symbolrate):
        self.__symbolrate = str(symbolrate)

    symbolrate = property(getSymbolrate, setSymbolrate)

    def setPlsCode(self, newPlsCode):
        self.__plscode = str(newPlsCode)

    plscode = property(lambda self: self.__plscode, setPlsCode)

    def setIsId(self, newIsId):
        self.__isid = str(newIsId)

    isid = property(lambda self: self.__isid, setIsId)

    def setT2miPlpId(self, newT2miPlpId):
        self.__t2mi_plp_id = str(newT2miPlpId)

    t2mi_plp_id = property(lambda self: self.__t2mi_plp_id, setT2miPlpId)

    def setT2miPid(self, newT2miPid):
        self.__t2mi_pid = str(newT2miPid)

    t2mi_pid = property(lambda self: self.__t2mi_pid, setT2miPid)

    def setTsid(self, newTsid):
        self.__tsid = str(newTsid)

    tsid = property(lambda self: self.__tsid, setTsid)

    def getOnid(self):
        return self.__onid

    def setOnid(self, newOnid):
        self.__onid = str(newOnid)

    onid = property(lambda self: self.__onid, setOnid)

    def exportImportColor(self):
        return {'import': self.__importColor}

    def exportSystem(self):
        return {'system': self.reTransSystem.get(self.system)}

    def exportFec(self):
        return {'fec_inner': self.reTransFec.get(self.fec)}

    def exportFrequency(self):
        return {'frequency': self.__frequency}

    def exportPolarisation(self):
        return {'polarization': self.reTransPolarisation.get(self.polarisation)}

    def exportSymbolrate(self):
        return {'symbol_rate': self.__symbolrate}

    def exportModulation(self):
        return {'modulation': self.reTransModulation.get(self.modulation)}

    def exportPlsMode(self):
        return {'pls_mode': self.reTransPlsMode.get(self.plsmode)}

    def exportPlsCode(self):
        return {'pls_code': self.__plscode}

    def exportIsId(self):
        return {'is_id': self.__isid}

    def exportT2miPlpId(self):
        return {'t2mi_plp_id': self.__t2mi_plp_id}

    def exportT2miPid(self):
        return {'t2mi_pid': self.__t2mi_pid}

    def exportOnid(self):
        return {'onid': self.__onid}

    def exportTsid(self):
        return {'tsid': self.__tsid}

    def exportInversion(self):
        return {'inversion': self.reTransOnOff.get(self.inversion)}

    def exportPilot(self):
        return {'pilot': self.reTransOnOff.get(self.pilot)}

    def exportRolloff(self):
        return {'rolloff': self.reTransRolloff.get(self.rolloff)}

    def exportClean(self):
        res = {}
        # Arrange the required columns from left to right.
        res.update(self.exportFrequency())
        res.update(self.exportSymbolrate())
        res.update(self.exportPolarisation())
        res.update(self.exportFec())
        res.update(self.exportSystem())
        res.update(self.exportModulation())
        
        # Add the rest of the ingredients
        if self.UseMultistream:
            res.update(self.exportIsId())
            res.update(self.exportPlsMode())
            res.update(self.exportPlsCode())
        if self.UseT2MI:
            res.update(self.exportT2miPlpId())
            res.update(self.exportT2miPid())
        if self.useOnid:
            res.update(self.exportOnid())
        if self.useTsid:
            res.update(self.exportTsid())
        if self.inversion != 'AUTO':
            res.update(self.exportInversion())
        if self.system == 'DVB-S2':
            if self.pilot != 'OFF':
                res.update(self.exportPilot())
        if self.rolloff != '0_35':
            res.update(self.exportRolloff())
        return res

    def exportAll(self):
        res = self.exportClean()
        res.update(self.exportImportColor())
        return res

class TransponderList(MenuList):

    def __init__(self, list=None):
        MenuList.__init__(self, list or [], enableWrapAround=True, content=eListboxPythonMultiContent)
        if FHD_Res:
            self.rowHight = 44
            self.l.setItemHeight(44)
            self.l.setFont(0, gFont('Regular', 29))
            self.l.setFont(1, gFont('Regular', 25))
        else:
            self.rowHight = 20
            self.l.setItemHeight(24)
            self.l.setFont(0, gFont('Regular', 22))
            self.l.setFont(1, gFont('Regular', 17))

    def getSelectedIndex(self):
        """Compatibility across images: return current selected row index or None."""
        # 1) MenuList API
        try:
            if hasattr(self, 'getSelectionIndex'):
                idx = self.getSelectionIndex()
                if idx is not None:
                    return idx
        except Exception:
            pass
        # 2) eListbox API
        try:
            idx = self.l.getCurrentSelectionIndex()
            if idx is not None:
                return idx
        except Exception:
            pass
        # 3) Fallback: compute from current selection object
        try:
            sel = self.l.getCurrentSelection()
            if sel is None:
                return None
            # MenuList stores entries in self.list on most images
            lst = getattr(self, 'list', None)
            if lst and sel in lst:
                return lst.index(sel)
        except Exception:
            pass
        return None

    def setEntries(self, transponderlist):
        transRolloff = {'0_35': '0.35',
         '0_25': '0.25',
         '0_20': '0.20',
         'Auto': 'Auto'}
        transFec = {'FEC_AUTO': 'Auto',
         'FEC_1_2': '1/2',
         'FEC_2_3': '2/3',
         'FEC_3_4': '3/4',
         'FEC_5_6': '5/6',
         'FEC_6_7': '6/7',
         'FEC_7_8': '7/8',
         'FEC_8_9': '8/9',
         'FEC_3_5': '3/5',
         'FEC_4_5': '4/5',
         'FEC_9_10': '9/10',
         'FEC_NONE': 'none'}
        res = []
        z = 0
        for x in transponderlist:
            transponder = Transponder(x)
            tp = []
            tp.append(z)
            z += 1
            calc_xpos = lambda a: a[len(a) - 1][1] + a[len(a) - 1][3]
            color = transponder.importColor
            if not config.misc.tssateditorT2MI.value:
                tsid_t2mi_plp_id = transponder.tsid
                onid_t2mi_pid = transponder.onid
            else:
                tsid_t2mi_plp_id = transponder.t2mi_plp_id
                onid_t2mi_pid = transponder.t2mi_pid
            if FHD_Res:
                tp.append(MultiContentEntryText(pos=(0, 0), size=(105, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.system, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(95, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=str(int(float(transponder.frequency)) // 1000), color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(70, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.polarisation, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(85, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=str(int(float(transponder.symbolrate)) // 1000), color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(80, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transFec.get(transponder.fec), color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(105, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.modulation, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(85, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transRolloff.get(transponder.rolloff), color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(85, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.inversion, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(80, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.pilot, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(75, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.isid, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(110, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.plsmode, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(110, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.plscode, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(80, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=tsid_t2mi_plp_id, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(80, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=onid_t2mi_pid, color=color, border_width=1, border_color=12092939))
            elif HD_Res:
                tp.append(MultiContentEntryText(pos=(0, 0), size=(75, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.system, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(65, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=str(int(float(transponder.frequency)) // 1000), color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(45, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.polarisation, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(60, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=str(int(float(transponder.symbolrate)) // 1000), color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(65, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transFec.get(transponder.fec), color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(85, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.modulation, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(60, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transRolloff.get(transponder.rolloff), color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(60, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.inversion, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(60, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.pilot, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(45, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.isid, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(70, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.plsmode, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(70, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.plscode, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(65, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=tsid_t2mi_plp_id, color=color, border_width=1, border_color=12092939))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(65, self.rowHight), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=onid_t2mi_pid, color=color, border_width=1, border_color=12092939))
            else:
                tp.append(MultiContentEntryText(pos=(0, 0), size=(55, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.system, color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(45, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=str(int(float(transponder.frequency)) // 1000), color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(23, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.polarisation, color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(48, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=str(int(float(transponder.symbolrate)) // 1000), color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(38, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transFec.get(transponder.fec), color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(48, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.modulation, color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(38, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transRolloff.get(transponder.rolloff), color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(38, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.inversion, color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(38, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.pilot, color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(33, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.isid, color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(46, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.plsmode, color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(38, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=transponder.plscode, color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(38, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=tsid_t2mi_plp_id, color=color, border_width=1, border_color=806544))
                tp.append(MultiContentEntryText(pos=(calc_xpos(tp), 0), size=(38, self.rowHight), font=1, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=onid_t2mi_pid, color=color, border_width=1, border_color=806544))
            res.append(tp)

        self.l.setList(res)

class Head(HTMLComponent, GUIComponent):
    def __init__(self):
        GUIComponent.__init__(self)
        self.l = eListboxPythonMultiContent()
        self.l.setSelectionClip(eRect(0, 0, 0, 0))
        if FHD_Res:
            self.l.setItemHeight(44)
            self.l.setFont(0, gFont('Regular', 25))
        else:
            self.l.setItemHeight(38)
            self.l.setFont(0, gFont('Regular', 17))

    GUI_WIDGET = eListbox

    def postWidgetCreate(self, instance):
        instance.setContent(self.l)

    def setEntries(self, data = None):
        res = [None]
        if data is not None:
            for x in data:
                if FHD_Res:
                    res.append(MultiContentEntryText(pos=(x[0], 0), size=(x[1], 40), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=safe_text(x[2]), color=12632256, backcolor=625428280, color_sel=16777215, backcolor_sel=627073024, border_width=1, border_color=15792383))
                else:
                    res.append(MultiContentEntryText(pos=(x[0], 0), size=(x[1], 20), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=safe_text(x[2]), color=12632256, backcolor=625428280, color_sel=16777215, backcolor_sel=627073024, border_width=1, border_color=15792383))

        self.l.setList([res])

class SatelliteList(MenuList):

    def __init__(self, list=None):
        MenuList.__init__(self, list or [], enableWrapAround=True, content=eListboxPythonMultiContent)
        if FHD_Res:
            self.l.setItemHeight(44)
            self.l.setFont(0, gFont('Regular', 29))
        else:
            self.l.setItemHeight(24)
            self.l.setFont(0, gFont('Regular', 22))

    def setEntries(self, satelliteslist):
        res = []
        for x in satelliteslist:
            satparameter = x[0]
            satentry = []
            pos = int(float(satparameter.get('position')))
            if pos < 0:
                pos += 3600
            satentry.append(pos)
            color = None
            color_sel = None
            if satparameter.get('selected', False):
                color = 0
                color_sel = 65344
            backcolor = None
            backcolor_sel = None
            a = FHD_Res and 1050 or HD_Res and 700 or 430
            b = FHD_Res and 255 or HD_Res and 170 or 103
            if len(x) == 1:
                backcolor = 1644912
                backcolor_sel = 9466996
            if FHD_Res:
                satentry.append(MultiContentEntryText(pos=(0, 0), size=(a, 40), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_TOP, text=safe_text(satparameter.get('name')), color=color, color_sel=color_sel, backcolor=backcolor, backcolor_sel=backcolor_sel, border_width=1, border_color=15792383))
            else:
                satentry.append(MultiContentEntryText(pos=(0, 0), size=(a, 24), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_TOP, text=safe_text(satparameter.get('name')), color=color, color_sel=color_sel, backcolor=backcolor, backcolor_sel=backcolor_sel, border_width=1, border_color=15792383))
            pos = int(float(satparameter.get('position')))
            posStr = str(abs(pos) // 10) + '.' + str(abs(pos) % 10)
            if pos < 0:
                posStr = posStr + ' ' + 'West'
            if pos > 0:
                posStr = posStr + ' ' + 'East'
            if pos == 0:
                posStr = posStr + ' ' + 'Greenwich'
            if FHD_Res:
                satentry.append(MultiContentEntryText(pos=(a, 0), size=(b, 40), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=safe_text(posStr), color=color, color_sel=color_sel, backcolor=backcolor, backcolor_sel=backcolor_sel, border_width=1, border_color=15792383))
            else:
                satentry.append(MultiContentEntryText(pos=(a, 0), size=(b, 24), font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=safe_text(posStr), color=color, color_sel=color_sel, backcolor=backcolor, backcolor_sel=backcolor_sel, border_width=1, border_color=15792383))
            res.append(satentry)

        self.l.setList(res)