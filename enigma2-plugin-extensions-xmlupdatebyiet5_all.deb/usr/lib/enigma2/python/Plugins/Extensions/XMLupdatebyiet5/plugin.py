# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

# Load plugin keymap (needed on some images so OK/ENTER triggers our Actions context)
try:
    from Tools.Directories import resolveFilename, SCOPE_PLUGINS
    from Components.ActionMap import loadKeymap
    loadKeymap(resolveFilename(SCOPE_PLUGINS, 'Extensions/XMLupdatebyiet5/keymap.xml'))
except Exception:
    try:
        from Tools.Directories import resolveFilename, SCOPE_PLUGINS
        from keymapparser import readKeymap
        readKeymap(resolveFilename(SCOPE_PLUGINS, 'Extensions/XMLupdatebyiet5/keymap.xml'))
    except Exception:
        pass

# plugin created by iet5

import os
import time
import shutil

from Plugins.Plugin import PluginDescriptor
from Components.config import (
    config, ConfigSubsection, ConfigYesNo, ConfigSelection,
    ConfigDirectory
)
from Tools.Directories import fileExists

# Restart GUI
try:
    from Screens.Standby import TryQuitMainloop
except Exception:
    TryQuitMainloop = None

# Python 2 / 3
try:
    from urllib.request import urlopen, Request
except Exception:
    from urllib2 import urlopen, Request


# HTTP errors (Python 2/3)
try:
    from urllib.error import HTTPError, URLError
except Exception:
    try:
        from urllib2 import HTTPError, URLError
    except Exception:
        HTTPError = URLError = Exception

# SSL compatibility (some images ship with old CA bundles)
try:
    import ssl
except Exception:
    ssl = None

def _patch_ssl_unverified():
    """Best-effort: allow HTTPS downloads on images with broken/old CA bundles."""
    if ssl is None:
        return None
    try:
        # Python 3: create context object for urlopen(context=...)
        return ssl._create_unverified_context()
    except Exception:
        try:
            # Python 2.7: affect global default HTTPS context if supported
            ssl._create_default_https_context = ssl._create_unverified_context
        except Exception:
            pass
    return None

# ---------------- Paths / Constants ----------------
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION_FILE = os.path.join(PLUGIN_DIR, "version.txt")
LOG_FILE = "/tmp/XMLupdatebyiet5.log"

URLS = {
    "satellites.xml": "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/refs/heads/master/src/satellites.xml",
    "terrestrial.xml": "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/refs/heads/master/src/terrestrial.xml",
    "cables.xml": "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/refs/heads/master/src/cables.xml",
}

DEFAULT_PATHS = ["/etc/tuxbox", "/etc/enigma2"]


# ---------------- Logging ----------------
def log_line(msg):
    try:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a") as f:
            f.write("[%s] %s\n" % (ts, msg))
    except Exception:
        pass

# ---------------- Config ----------------
config.plugins.XMLupdatebyiet5 = ConfigSubsection()
config.plugins.XMLupdatebyiet5.do_sat = ConfigYesNo(default=True)
config.plugins.XMLupdatebyiet5.do_ter = ConfigYesNo(default=True)
config.plugins.XMLupdatebyiet5.do_cab = ConfigYesNo(default=True)
config.plugins.XMLupdatebyiet5.restart_gui_after_update = ConfigYesNo(default=False)

config.plugins.XMLupdatebyiet5.save_mode = ConfigSelection(
    default="both",
    choices=[
        ("both", "Save to: /etc/tuxbox and /etc/enigma2"),
        ("tuxbox", "Save to: /etc/tuxbox only"),
        ("enigma2", "Save to: /etc/enigma2 only"),
        ("custom", "Save to: custom path"),
    ]
)
config.plugins.XMLupdatebyiet5.custom_path = ConfigDirectory(default="/etc")

# ---------------- Helpers ----------------
def read_version():
    try:
        if fileExists(VERSION_FILE):
            s = open(VERSION_FILE).read().strip()
            return s if s else "ver.00"
    except Exception:
        pass
    return "ver.00"

def get_selected_files():
    files = []
    if config.plugins.XMLupdatebyiet5.do_sat.value:
        files.append("satellites.xml")
    if config.plugins.XMLupdatebyiet5.do_ter.value:
        files.append("terrestrial.xml")
    if config.plugins.XMLupdatebyiet5.do_cab.value:
        files.append("cables.xml")
    return files

def get_target_paths():
    mode = config.plugins.XMLupdatebyiet5.save_mode.value
    if mode == "both":
        return list(DEFAULT_PATHS)
    if mode == "tuxbox":
        return ["/etc/tuxbox"]
    if mode == "enigma2":
        return ["/etc/enigma2"]
    return [config.plugins.XMLupdatebyiet5.custom_path.value]

def download_url(url):
    # GitHub raw URLs sometimes change (e.g. refs/heads/master vs master).
    # We try the given URL first, then fall back if needed.
    urls_to_try = [url]
    if "/refs/heads/" in url:
        urls_to_try.append(url.replace("/refs/heads/", "/"))
    # Add the classic raw format fallback
    if "raw.githubusercontent.com/" in url and "/refs/heads/" not in url:
        # nothing to do
        pass

    ctx = _patch_ssl_unverified()
    last_err = None

    for u in urls_to_try:
        try:
            req = Request(u, headers={"User-Agent": "XMLupdatebyiet5"})
            try:
                # Python 3
                if ctx is not None:
                    return urlopen(req, timeout=25, context=ctx).read()
            except TypeError:
                # Python 2: no context kwarg
                pass
            return urlopen(req, timeout=25).read()
        except HTTPError as e:
            last_err = e
            # Retry next URL on 404/redirect-related issues
            try:
                if hasattr(e, "code") and int(e.code) == 404:
                    continue
            except Exception:
                pass
        except URLError as e:
            last_err = e
        except Exception as e:
            last_err = e

    if last_err:
        raise last_err
    raise Exception("Download failed")

def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def backup_file(path):
    """
    Backup naming requested:
      satellites.xml.bak-20260205-14:31:46
    """
    if not fileExists(path):
        return True
    # Date part without ":" and time part with ":".
    stamp = time.strftime("%Y:%m:%d-%H:%M:%S")
    bak = "%s.bak-%s" % (path, stamp)
    shutil.copy2(path, bak)
    log_line("Backup created: %s" % bak)
    return True

def atomic_write(path, data):
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        try:
            os.fsync(f.fileno())
        except Exception:
            pass
    os.rename(tmp, path)
    return True

def run_download(progress_cb=None, status_cb=None):
    """
    Perform download + backup + write.

    Returns dict:
      {
        "targets": [...],
        "downloaded_files": int,
        "ok_copies": int,
        "fail_copies": int,
        "all_ok": bool
      }

    progress_cb(percent:int) optional
    status_cb(text:str) optional
    """
    files = get_selected_files()
    targets = get_target_paths()

    if not files:
        return {
            "targets": targets,
            "downloaded_files": 0,
            "ok_copies": 0,
            "fail_copies": 0,
            "all_ok": False
        }

    steps = len(files) * len(targets)
    done = 0

    downloaded_files = 0
    ok_copies = 0
    fail_copies = 0

    log_line("Download started. Targets=%s Files=%s" % (",".join(targets), ",".join(files)))

    # Ensure dirs first
    for t in targets:
        try:
            ensure_dir(t)
        except Exception as e:
            log_line("Cannot create/access directory: %s (%s)" % (t, str(e)))
            return {
                "targets": targets,
                "downloaded_files": 0,
                "ok_copies": 0,
                "fail_copies": steps,
                "all_ok": False
            }

    for fname in files:
        if status_cb:
            try:
                status_cb("Downloading %s..." % fname)
            except Exception:
                pass

        try:
            data = download_url(URLS[fname])
            downloaded_files += 1
        except Exception as e:
            log_line("Download failed: %s (%s)" % (fname, str(e)))
            # this file fails for all targets
            fail_copies += len(targets)
            done += len(targets)
            if progress_cb and steps:
                try:
                    progress_cb(int((done * 100) / steps))
                except Exception:
                    pass
            continue

        for t in targets:
            try:
                if status_cb:
                    try:
                        status_cb("Saving %s to %s..." % (fname, t))
                    except Exception:
                        pass

                path = os.path.join(t, fname)
                backup_file(path)
                atomic_write(path, data)
                ok_copies += 1
                log_line("Saved: %s" % path)
            except Exception as e:
                fail_copies += 1
                log_line("Save failed: %s (%s)" % (os.path.join(t, fname), str(e)))

            done += 1
            if progress_cb and steps:
                try:
                    progress_cb(int((done * 100) / steps))
                except Exception:
                    pass

    all_ok = (fail_copies == 0)
    log_line("Download finished. Downloaded_files=%d Saved_copies=%d Failed_copies=%d"
             % (downloaded_files, ok_copies, fail_copies))

    return {
        "targets": targets,
        "downloaded_files": downloaded_files,
        "ok_copies": ok_copies,
        "fail_copies": fail_copies,
        "all_ok": all_ok
    }

def can_restart_gui():
    return TryQuitMainloop is not None

def do_restart_gui(session):
    if TryQuitMainloop is None:
        return False
    session.open(TryQuitMainloop, 3)
    return True

# ---------------- Enigma2 Entry ----------------
def main(session, **kwargs):
    try:
        # main UI renamed from screen.py -> mainscreen.py
        from .mainscreen import XMLupdateByIet5Screen
        session.openWithCallback(lambda *args, **kwargs: None, XMLupdateByIet5Screen)
    except Exception as e:
        try:
            from Screens.MessageBox import MessageBox
            session.open(MessageBox, "Failed to open main screen.\n%s" % str(e), MessageBox.TYPE_ERROR)
        except Exception:
            pass

def Plugins(**kwargs):
    desc = "Download and update satellites/terrestrial/cables XML files"
    return [
        PluginDescriptor(
            name="XMLupdatebyiet5",
            description=desc,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        ),
        PluginDescriptor(
            name="XMLupdatebyiet5",
            description=desc,
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            icon="plugin.png",
            fnc=main
        )
    ]