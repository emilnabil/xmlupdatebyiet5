# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
from __future__ import division

# Createded by iet5
import os
import time
from xml.etree import ElementTree as ET

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager import nimmanager
from Tools.Directories import fileExists
from enigma import (
    eListbox, gFont, eListboxPythonMultiContent,
    RT_HALIGN_LEFT, RT_HALIGN_CENTER,
    RT_VALIGN_CENTER, RT_VALIGN_TOP,
    eRect, getDesktop,
    eTimer
)

# Python 2/3 compatibility
import sys
PY3 = sys.version_info[0] == 3

# Import from components module
try:
    from .components import (
        FHD_Res, need_update, config,
        Transponder, TransponderList, Head, SatelliteList,
        currversion, safe_text
    )
    from .sateditscreen import SatEditor
    from .transponderseditor import TranspondersEditor
except ImportError:
    # Fallback for direct import
    from components import (
        FHD_Res, need_update, config,
        Transponder, TransponderList, Head, SatelliteList,
        currversion, safe_text
    )
    from sateditscreen import SatEditor

# --- Ensure we always use the packaged SatEditor (avoid wrong absolute imports on some images) ---
try:
    from .sateditscreen import SatEditor as _SatEditor
    SatEditor = _SatEditor
except Exception:
    pass
    from transponderseditor import TranspondersEditor

# Import _ for translations
try:
    from . import _
except ImportError:
    _ = lambda x: x


class SatXmlEditScreen(Screen):
    # FHD screen size reverted to 1320x800,
    skin = """
        <screen name="SatXmlEditScreen" position="center,center" size="1320,800" title="Satellite.XML Editor by iet5" >
            <ePixmap pixmap="skin_default/buttons/red.png" position="40,0" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/green.png" position="360,0" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/yellow.png" position="680,0" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/blue.png" position="1000,0" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/ok.png" position="1275,5" size="35,35" alphatest="on" />
            <widget name="key_menu" zPosition="1" pixmap="skin_default/buttons/key_menu.png" position="1220,10" size="35,25" alphatest="on" />

            <widget name="key_red" position="40,0" zPosition="1" size="300,70" font="Regular;32" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
            <widget name="key_green" position="360,0" zPosition="1" size="300,70" font="Regular;32" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
            <widget name="key_yellow" position="680,0" zPosition="1" size="300,70" font="Regular;32" halign="center" valign="center" backgroundColor="#a08500" transparent="1" />
            <widget name="key_blue" position="1000,0" zPosition="1" size="300,70" font="Regular;32" halign="center" valign="center" backgroundColor="#18188b" transparent="1" />

            <widget name="list" position="10,125" size="1300,490" scrollbarMode="showOnDemand" />
            <widget name="head" position="10,80" size="1300,40" scrollbarMode="showNever" />
            <widget name="polhead" position="100,630" size="1220,40" />
            <widget name="bandlist" position="10,670" size="90,120" />
            <widget name="infolist" position="100,670" zPosition="2" size="1220,120" />
        </screen>
        """

    def __init__(self, session):
        Screen.__init__(self, session)

        # Initialize widgets
        self['key_red'] = Button(_('Delete'))
        self['key_green'] = Button(_('Edit'))
        self['key_yellow'] = Button(_('Add'))
        self['key_blue'] = Button(_('Sort'))
        self['key_menu'] = Pixmap()
        self['key_menu'].hide()

        # Initialize MenuList widgets
        self['infolist'] = MenuList([])
        self['polhead'] = MenuList([])
        self['bandlist'] = MenuList([])

        # --- Make list widgets MultiContent like the original Mainfile.py (keeps same look/behavior) ---
        # Note: We do NOT remove any existing lines; we only extend behavior here.
        from enigma import eListboxPythonMultiContent, eRect, gFont

        # infolist
        try:
            self['infolist'].l = eListboxPythonMultiContent()
            self['infolist'].l.setSelectionClip(eRect(0, 0, 0, 0))
            if FHD_Res:
                # Font +2 for the on-screen lists (27 -> 28)
                self['infolist'].l.setItemHeight(42)
                self['infolist'].l.setFont(0, gFont('Regular', 28))
            else:
                self['infolist'].l.setItemHeight(24)
                self['infolist'].l.setFont(0, gFont('Regular', 19))
        except Exception:
            pass

        # polhead
        try:
            self['polhead'].l = eListboxPythonMultiContent()
            self['polhead'].l.setSelectionClip(eRect(0, 0, 0, 0))
            if FHD_Res:
                # Font +2 (27 -> 29)
                self['polhead'].l.setItemHeight(42)
                self['polhead'].l.setFont(0, gFont('Regular', 28))
            else:
                self['polhead'].l.setItemHeight(24)
                self['polhead'].l.setFont(0, gFont('Regular', 19))
        except Exception:
            pass

        # bandlist
        try:
            self['bandlist'].l = eListboxPythonMultiContent()
            self['bandlist'].l.setSelectionClip(eRect(0, 0, 0, 0))
            if FHD_Res:
                # Font +2 (27 -> 29)
                self['bandlist'].l.setItemHeight(42)
                self['bandlist'].l.setFont(0, gFont('Regular', 28))
            else:
                self['bandlist'].l.setItemHeight(24)
                self['bandlist'].l.setFont(0, gFont('Regular', 19))
        except Exception:
            pass

        # Now set up the ActionMap
        self['actions'] = ActionMap(['SatellitesEditorActions', 'OkCancelActions'], {
            'nextPage': self.nextPage,
            'prevPage': self.prevPage,
            'displayHelp': self.showHelp,
            'displayInfo': self.showSatelliteInfo,
            'select': self.editTransponders,
            'ok': self.editTransponders,
            'exit': self.Exit,
            'left': self.left,
            'leftUp': self.doNothing,
            'leftRepeated': self.doNothing,
            'displayMenu': self.blihdscanXML,
            'right': self.right,
            'rightUp': self.doNothing,
            'rightRepeated': self.doNothing,
            'upUp': self.upUp,
            'up': self.up,
            'upRepeated': self.upRepeated,
            'down': self.down,
            'downUp': self.downUp,
            'downRepeated': self.downRepeated,
            'red': self.removeSatellite,
            'green': self.editSatellite,
            'yellow': self.addSatellite,
            'blue': self.sortColumn
        }, -1)

        # Select satellites.xml path (different images use different locations)
        self.satfile = None
        for _p in ('/etc/enigma2/satellites.xml', '/etc/tuxbox/satellites.xml', '/usr/share/enigma2/satellites.xml'):
            if fileExists(_p) or os.path.exists(_p):
                self.satfile = _p
                break
        if self.satfile is None:
            # Fallback to default path; we'll show an error after the screen is shown
            self.satfile = '/etc/enigma2/satellites.xml'

        # Read satellites (do NOT open MessageBox during __init__ on some images, it can crash with modal errors)
        self._sat_read_error = None
        try:
            self.satelliteslist = self.readSatellites(self.satfile, stop=False)
        except Exception as _e:
            self.satelliteslist = []
            self._sat_read_error = str(_e)


        # Initialize other widgets
        self['head'] = Head()
        self['list'] = SatelliteList()

        if self.satelliteslist:
            self['list'].setEntries(self.satelliteslist)

        # --- Increase the font of the header row text ("Satellites" / "Position") by +2 ---
        # This affects the line right under the color buttons (the Head widget).
        try:
            if FHD_Res and hasattr(self['head'], 'l'):
                self['head'].l.setItemHeight(42)
                _hf = gFont('Regular', 29)  # +2 (27 -> 29)
                try:
                    self['head'].l.setFont(0, _hf)
                except TypeError:
                    try:
                        self['head'].l.setFont(_hf)
                    except Exception:
                        pass
        except Exception:
            pass

        # Configure list widgets
        if FHD_Res:
            # Font +2 (27 -> 28)
            self['infolist'].l.setItemHeight(41)
            _f = gFont('Regular', 28)
            try:
                self['infolist'].l.setFont(0, _f)  # original API (multi-font content)
            except TypeError:
                try:
                    self['infolist'].l.setFont(_f)  # fallback for eListboxPythonStringContent
                except Exception:
                    pass
            # self['infolist'].l.setFont(0, gFont('Regular', 28))

            self['polhead'].l.setItemHeight(41)
            _f = gFont('Regular', 28)
            try:
                self['polhead'].l.setFont(0, _f)  # original API (multi-font content)
            except TypeError:
                try:
                    self['polhead'].l.setFont(_f)  # fallback for eListboxPythonStringContent
                except Exception:
                    pass
            # self['polhead'].l.setFont(0, gFont('Regular', 28))

            self['bandlist'].l.setItemHeight(41)
            _f = gFont('Regular', 29)
            try:
                self['bandlist'].l.setFont(0, _f)  # original API (multi-font content)
            except TypeError:
                try:
                    self['bandlist'].l.setFont(_f)  # fallback for eListboxPythonStringContent
                except Exception:
                    pass
            # self['bandlist'].l.setFont(0, gFont('Regular', 28))
        else:
            self['infolist'].l.setItemHeight(23)
            _f = gFont('Regular', 20)
            try:
                self['infolist'].l.setFont(0, _f)
            except TypeError:
                try:
                    self['infolist'].l.setFont(_f)
                except Exception:
                    pass

            self['polhead'].l.setItemHeight(23)
            _f = gFont('Regular', 20)
            try:
                self['polhead'].l.setFont(0, _f)
            except TypeError:
                try:
                    self['polhead'].l.setFont(_f)
                except Exception:
                    pass

            self['bandlist'].l.setItemHeight(23)
            _f = gFont('Regular', 20)
            try:
                self['bandlist'].l.setFont(0, _f)
            except TypeError:
                try:
                    self['bandlist'].l.setFont(_f)
                except Exception:
                    pass

        self.onLayoutFinish.append(self.layoutFinished)
        self.currentSelectedColumn = 0
        self.addNewSat = None
        self.updateSatList = False
        self.row = [['name', _('Satellites'), False], ['position', _('Position'), False]]
        self.lastSelectedIndex = 0

    def layoutFinished(self):
        global need_update
        need_update = False
        self.cleansatellitesxml()
        self.setTitle("Satellite.XML Editor by iet5")

        # Check for blindscan file and show menu button if exists
        if self.isBlihdscanXML():
            self['key_menu'].show()
        else:
            self['key_menu'].hide()

        # If satellites.xml could not be loaded, show the error AFTER the screen is shown (prevents modal-open crashes)
        if not self.satelliteslist:
            def _show_err():
                msg = self._sat_read_error or ("File not found: %s" % self.satfile)
                try:
                    self.session.open(MessageBox, msg, MessageBox.TYPE_ERROR)
                except Exception as e:
                    print("[SatXmlEditScreen] deferred error MessageBox failed:", str(e))
                try:
                    self.close()
                except Exception:
                    pass

            try:
                t = eTimer()
                self._defer_timer = t
                try:
                    t.callback.append(_show_err)
                except Exception:
                    t.timeout.connect(_show_err)  # some images
                t.start(200, True)
            except Exception as e:
                print("[SatXmlEditScreen] failed to create defer timer:", str(e))
                _show_err()
            return

        try:
            if self.satelliteslist:
                self['list'].setEntries(self.satelliteslist)

            # Update head
            if self['list'].l.getCurrentSelection():
                row = self['list'].l.getCurrentSelection()
                if row and len(row) > 1:
                    head = []
                    for x in range(1, len(row)):
                        head.append([row[x][1], row[x][3], ''])

                    head[0][2] = self.row[0][1]
                    head[1][2] = self.row[1][1]
                    self['head'].setEntries(head)

                    # Update selection
                    data = self['head'].l.getCurrentSelection()
                    if data and len(data) > self.currentSelectedColumn + 1:
                        data = data[self.currentSelectedColumn + 1]
                        self['head'].l.setSelectionClip(eRect(data[1], data[0], data[3], data[4]), True)

                self.updateSelection()
        except Exception as e:
            print("[SatXmlEditScreen] layoutFinished error:", str(e))

    def updateSelection(self):
        row = self['list'].l.getCurrentSelection()
        if row is None or len(row) < 2:
            return
        firstColumn = row[1]
        lastColumn = row[len(row) - 1]
        self['list'].l.setSelectionClip(
            eRect(firstColumn[1], firstColumn[0],
                  lastColumn[1] + lastColumn[3], lastColumn[4]),
            True
        )
        self.getInfo()

    def doNothing(self):
        pass

    def left(self):
        if self.currentSelectedColumn:
            self.currentSelectedColumn -= 1
            data = self['head'].l.getCurrentSelection()
            if data and len(data) > self.currentSelectedColumn + 1:
                data = data[self.currentSelectedColumn + 1]
                self['head'].l.setSelectionClip(eRect(data[1], data[0], data[3], data[4]), True)

    def right(self):
        if self.currentSelectedColumn < len(self.row) - 1:
            self.currentSelectedColumn += 1
            data = self['head'].l.getCurrentSelection()
            if data and len(data) > self.currentSelectedColumn + 1:
                data = data[self.currentSelectedColumn + 1]
                self['head'].l.setSelectionClip(eRect(data[1], data[0], data[3], data[4]), True)

    def nextPage(self):
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None:
            return
        self['list'].pageUp()
        self.lastSelectedIndex = cur_idx
        self.updateSelection()

    def prevPage(self):
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None:
            return
        self['list'].pageDown()
        self.lastSelectedIndex = cur_idx
        self.updateSelection()

    def up(self):
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None:
            return
        self['list'].up()
        self.lastSelectedIndex = cur_idx
        self.updateSelection()

    def down(self):
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None:
            return
        self['list'].down()
        self.lastSelectedIndex = cur_idx
        self.updateSelection()

    def upUp(self):
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None and self.lastSelectedIndex != cur_idx:
            self.lastSelectedIndex = cur_idx

    def downUp(self):
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None and self.lastSelectedIndex != cur_idx:
            self.lastSelectedIndex = cur_idx

    def upRepeated(self):
        self['list'].up()
        self.updateSelection()

    def downRepeated(self):
        self['list'].down()
        self.updateSelection()

    def getInfo(self):
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None or cur_idx >= len(self.satelliteslist):
            return

        satellite = self.satelliteslist[cur_idx]
        self.name = satellite[0].get('name', '')
        self.position = satellite[0].get('position', '0')

        # Initialize counters
        self.tp_ku_h = self.tp_ku_v = self.tp_ku_l = self.tp_ku_r = 0
        self.tp_ku_h2 = self.tp_ku_v2 = self.tp_ku_l2 = self.tp_ku_r2 = 0
        self.tp_c_h = self.tp_c_v = self.tp_c_l = self.tp_c_r = 0
        self.tp_c_h2 = self.tp_c_v2 = self.tp_c_l2 = self.tp_c_r2 = 0

        if len(satellite) > 1:
            for tp in satellite[1]:
                freq_str = tp.get('frequency', '0')
                pol = tp.get('polarization', '0')
                system = tp.get('system', '0')

                try:
                    freq = int(freq_str)
                except:
                    freq = 0

                if 10700000 <= freq <= 26500000:
                    if system == '0':
                        if pol == '0': self.tp_ku_h += 1
                        elif pol == '1': self.tp_ku_v += 1
                        elif pol == '2': self.tp_ku_l += 1
                        elif pol == '3': self.tp_ku_r += 1
                    elif system == '1':
                        if pol == '0': self.tp_ku_h2 += 1
                        elif pol == '1': self.tp_ku_v2 += 1
                        elif pol == '2': self.tp_ku_l2 += 1
                        elif pol == '3': self.tp_ku_r2 += 1
                elif 3400000 <= freq <= 4200000:
                    if system == '0':
                        if pol == '0': self.tp_c_h += 1
                        elif pol == '1': self.tp_c_v += 1
                        elif pol == '2': self.tp_c_l += 1
                        elif pol == '3': self.tp_c_r += 1
                    elif system == '1':
                        if pol == '0': self.tp_c_h2 += 1
                        elif pol == '1': self.tp_c_v2 += 1
                        elif pol == '2': self.tp_c_l2 += 1
                        elif pol == '3': self.tp_c_r2 += 1

# Determine band text
#         text_band = 'Ku/Ka'
#         if (self.tp_ku_h or self.tp_ku_v or self.tp_ku_l or self.tp_ku_r or
#             self.tp_ku_h2 or self.tp_ku_v2 or self.tp_ku_l2 or self.tp_ku_r2):
#             text_band = 'Ku'
#
#         # Update bandlist
#         entryList = ('Band', text_band, 'C')
#         l = []
#         for entry in entryList:
#             bandList = [None]
#             if FHD_Res:
#                 bandList.append(MultiContentEntryText(pos=(0, 0), size=(120, 40), font=0,
#                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=str(entry),
#                     border_width=1, border_color=15792383))
#             elif HD_Res:
#                 bandList.append(MultiContentEntryText(pos=(0, 0), size=(80, 24), font=0,
#                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=str(entry),
#                     border_width=1, border_color=15792383))
#             else:
#                 bandList.append(MultiContentEntryText(pos=(0, 0), size=(55, 24), font=0,
#                     flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER, text=str(entry),
#                     border_width=1, border_color=15792383))
#             l.append(bandList)
#         self['bandlist'].l.setList(l)
#
#         # Update polarization header
#         calc_xpos = lambda a: a[len(a) - 1][1] + a[len(a) - 1][3]
#         entryList = (_('horizontal'), _('vertical'), _('circular left'), _('circular right'))
#         xpos = 0
#         polarisationList = [None]
#         x = FHD_Res and 275 or HD_Res and 205 or 125
#         for entry in entryList:
#             if FHD_Res:
#                 polarisationList.append(MultiContentEntryText(pos=(xpos, 0), size=(x, 40), font=0,
#                     flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=str(entry),
#                     border_width=1, border_color=15792383))
#             else:
#                 polarisationList.append(MultiContentEntryText(pos=(xpos, 0), size=(x, 24), font=0,
#                     flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=str(entry),
#                     border_width=1, border_color=15792383))
#             xpos = calc_xpos(polarisationList)
#         self['polhead'].l.setList([polarisationList])
#
#         # Update info list
#         l = []
#         # Ku band info
#         infolist = [None]
#         if FHD_Res:
#             entries = [
#                 (str(self.tp_ku_h), 130), (str(self.tp_ku_h2), 145),
#                 (str(self.tp_ku_v), 130), (str(self.tp_ku_v2), 145),
#                 (str(self.tp_ku_l), 130), (str(self.tp_ku_l2), 145),
#                 (str(self.tp_ku_r), 130), (str(self.tp_ku_r2), 145)
#             ]
#             y = 75
#         elif HD_Res:
#             entries = [
#                 (str(self.tp_ku_h), 100), (str(self.tp_ku_h2), 105),
#                 (str(self.tp_ku_v), 100), (str(self.tp_ku_v2), 105),
#                 (str(self.tp_ku_l), 100), (str(self.tp_ku_l2), 105),
#                 (str(self.tp_ku_r), 100), (str(self.tp_ku_r2), 105)
#             ]
#             y = 50
#         else:
#             entries = [
#                 (str(self.tp_ku_h), 60), (str(self.tp_ku_h2), 65),
#                 (str(self.tp_ku_v), 60), (str(self.tp_ku_v2), 65),
#                 (str(self.tp_ku_l), 60), (str(self.tp_ku_l2), 65),
#                 (str(self.tp_ku_r), 60), (str(self.tp_ku_r2), 65)
#             ]
#             y = 24
#
#         xpos = 0
#         for text, width in entries:
#             infolist.append(MultiContentEntryText(pos=(xpos, 0), size=(width, y), font=0,
#                 flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=text,
#                 border_width=1, border_color=15792383))
#             xpos = calc_xpos(infolist)
#         l.append(infolist)
#
#         # C band info
#         infolist = [None]
#         if FHD_Res:
#             entries = [
#                 (str(self.tp_c_h), 130), (str(self.tp_c_h2), 145),
#                 (str(self.tp_c_v), 130), (str(self.tp_c_v2), 145),
#                 (str(self.tp_c_l), 130), (str(self.tp_c_l2), 145),
#                 (str(self.tp_c_r), 130), (str(self.tp_c_r2), 145)
#             ]
#             y = 40
#         elif HD_Res:
#             entries = [
#                 (str(self.tp_c_h), 100), (str(self.tp_c_h2), 105),
#                 (str(self.tp_c_v), 100), (str(self.tp_c_v2), 105),
#                 (str(self.tp_c_l), 100), (str(self.tp_c_l2), 105),
#                 (str(self.tp_c_r), 100), (str(self.tp_c_r2), 105)
#             ]
#             y = 24
#         else:
#             entries = [
#                 (str(self.tp_c_h), 60), (str(self.tp_c_h2), 65),
#                 (str(self.tp_c_v), 60), (str(self.tp_c_v2), 65),
#                 (str(self.tp_c_l), 60), (str(self.tp_c_l2), 65),
#                 (str(self.tp_c_r), 60), (str(self.tp_c_r2), 65)
#             ]
#             y = 24
#
#         xpos = 0
#         for text, width in entries:
#             infolist.append(MultiContentEntryText(pos=(xpos, 0), size=(width, y), font=0,
#                 flags=RT_HALIGN_CENTER | RT_VALIGN_TOP, text=text,
#                 border_width=1, border_color=15792383))
#             xpos = calc_xpos(infolist)
#         l.append(infolist)
#
#         self['infolist'].l.setList(l)

        # --- Restored original Mainfile.py layout/content for bandlist/polhead/infolist ---
        ku_band = False
        ka_band = False
        # Detect Ku/Ka (same as original logic)
        for tp in satellite[1]:
            try:
                freq = int(tp.get('frequency', '0'))
            except Exception:
                freq = 0
            if 10700000 <= freq <= 26500000:
                if freq < 12751000:
                    ku_band = True
                else:
                    ka_band = True

        text_band = 'Ku/Ka'
        if ku_band and not ka_band:
            text_band = 'Ku'
        if ka_band and not ku_band:
            text_band = 'Ka'

        # Band list (Band / Ku/Ka / C)
        entryList = ('Band', text_band, 'C')
        l = []
        for entry in entryList:
            bandList = [None]
            if FHD_Res:
                bandList.append(MultiContentEntryText(
                    pos=(0, 0), size=(120, 40), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=entry, border_width=1, border_color=15792383
                ))
            else:
                bandList.append(MultiContentEntryText(
                    pos=(0, 0), size=(55, 24), font=0,
                    flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                    text=entry, border_width=1, border_color=15792383
                ))
            l.append(bandList)
        self['bandlist'].l.setList(l)

        # Polarization header
        calc_xpos = lambda a: a[len(a) - 1][1] + a[len(a) - 1][3]
        entryList = (_('horizontal'), _('vertical'), _('circular left'), _('circular right'))
        xpos = 0
        polarisationList = [None]
        x = FHD_Res and 275 or 125
        for entry in entryList:
            if FHD_Res:
                polarisationList.append(MultiContentEntryText(
                    pos=(xpos, 0), size=(x, 40), font=0,
                    flags=RT_HALIGN_CENTER | RT_VALIGN_TOP,
                    text=entry, border_width=1, border_color=15792383
                ))
            else:
                polarisationList.append(MultiContentEntryText(
                    pos=(xpos, 0), size=(x, 24), font=0,
                    flags=RT_HALIGN_CENTER | RT_VALIGN_TOP,
                    text=entry, border_width=1, border_color=15792383
                ))
            xpos = calc_xpos(polarisationList)
        self['polhead'].l.setList([polarisationList])

        # Info list (same 3 rows as original: labels row + Ku counts + C counts)
        l = []
        infolist = [None]
        if FHD_Res:
            entryList = (('dvb-s', 130), ('dvb-s2', 145), ('dvb-s', 130), ('dvb-s2', 145),
                         ('dvb-s', 130), ('dvb-s2', 145), ('dvb-s', 130), ('dvb-s2', 145))
        else:
            entryList = (('dvb-s', 60), ('dvb-s2', 65), ('dvb-s', 60), ('dvb-s2', 65),
                         ('dvb-s', 60), ('dvb-s2', 65), ('dvb-s', 60), ('dvb-s2', 65))
        xpos = 0
        y = FHD_Res and 75 or 24
        for entry in entryList:
            infolist.append(MultiContentEntryText(
                pos=(xpos, 0), size=(entry[1], y), font=0,
                flags=RT_HALIGN_CENTER | RT_VALIGN_TOP,
                text=entry[0], border_width=1, border_color=15792383
            ))
            xpos = calc_xpos(infolist)
        l.append(infolist)

        # Ku counts row
        infolist = [None]
        if FHD_Res:
            entryList = ((self.tp_ku_h, 130), (self.tp_ku_h2, 145), (self.tp_ku_v, 130), (self.tp_ku_v2, 145),
                         (self.tp_ku_l, 130), (self.tp_ku_l2, 145), (self.tp_ku_r, 130), (self.tp_ku_r2, 145))
        else:
            entryList = ((self.tp_ku_h, 60), (self.tp_ku_h2, 65), (self.tp_ku_v, 60), (self.tp_ku_v2, 65),
                         (self.tp_ku_l, 60), (self.tp_ku_l2, 65), (self.tp_ku_r, 60), (self.tp_ku_r2, 65))
        xpos = 0
        for entry in entryList:
            infolist.append(MultiContentEntryText(
                pos=(xpos, 0), size=(entry[1], y), font=0,
                flags=RT_HALIGN_CENTER | RT_VALIGN_TOP,
                text=str(entry[0]).lstrip('0'), border_width=1, border_color=15792383
            ))
            xpos = calc_xpos(infolist)
        l.append(infolist)

        # C counts row
        infolist = [None]
        if FHD_Res:
            entryList = ((self.tp_c_h, 130), (self.tp_c_h2, 145), (self.tp_c_v, 130), (self.tp_c_v2, 145),
                         (self.tp_c_l, 130), (self.tp_c_l2, 145), (self.tp_c_r, 130), (self.tp_c_r2, 145))
        else:
            entryList = ((self.tp_c_h, 60), (self.tp_c_h2, 65), (self.tp_c_v, 60), (self.tp_c_v2, 65),
                         (self.tp_c_l, 60), (self.tp_c_l2, 65), (self.tp_c_r, 60), (self.tp_c_r2, 65))
        xpos = 0
        for entry in entryList:
            if FHD_Res:
                infolist.append(MultiContentEntryText(
                    pos=(xpos, 0), size=(entry[1], 40), font=0,
                    flags=RT_HALIGN_CENTER | RT_VALIGN_TOP,
                    text=str(entry[0]).lstrip('0'), border_width=1, border_color=15792383
                ))
            else:
                infolist.append(MultiContentEntryText(
                    pos=(xpos, 0), size=(entry[1], 24), font=0,
                    flags=RT_HALIGN_CENTER | RT_VALIGN_TOP,
                    text=str(entry[0]).lstrip('0'), border_width=1, border_color=15792383
                ))
            xpos = calc_xpos(infolist)
        l.append(infolist)

        self['infolist'].l.setList(l)

    def readSatellites(self, file, stop=True):
        if not fileExists(file):
            if stop:
                self.session.open(MessageBox, _("File not found: %s") % file, MessageBox.TYPE_ERROR)
                self.close()
            else:
                self['key_menu'].hide()
            return []

        try:
            satellitesXML = ET.parse(file)
            satDict = satellitesXML.getroot()
            satelliteslist = []

            # Python 2/3 compatibility
            if PY3:
                sat_elements = satDict.iter('sat')
            else:
                sat_elements = satDict.getiterator('sat')

            for sat in sat_elements:
                transponderslist = []

                if PY3:
                    tp_elements = sat.iter('transponder')
                else:
                    tp_elements = sat.getiterator('transponder')

                for transponder in tp_elements:
                    transponderslist.append(transponder.attrib)

                sat_name = sat.attrib.get('name', 'new Satellite')
                # Handle encoding for Python 2
                if not PY3 and isinstance(sat_name, str):
                    try:
                        sat_name = sat_name.decode('utf-8')
                    except:
                        pass

                sat.attrib['name'] = sat_name
                satelliteslist.append([sat.attrib, transponderslist])

            return satelliteslist

        except Exception as e:
            print("[SatXmlEditScreen] readSatellites error:", str(e))
            if stop:
                self.session.open(MessageBox, _("Error reading file: %s") % str(e), MessageBox.TYPE_ERROR)
                self.close()
            else:
                self['key_menu'].hide()
            return []

    def writeSatellites(self):
        try:
            root = ET.Element('satellites')
            root.text = '\n\t'

            for x in self.satelliteslist:
                satellite = ET.SubElement(root, 'sat', x[0])
                satellite.text = '\n\t\t'
                satellite.tail = '\n\t'

                for y in x[1]:
                    y_clean = Transponder(y).exportClean()
                    transponder = ET.SubElement(satellite, 'transponder', y_clean)
                    transponder.tail = '\n\t\t'

                if x[1]:
                    transponder.tail = '\n\t'

            if self.satelliteslist:
                satellite.tail = '\n'

            tree = ET.ElementTree(root)

            # Backup original file
            src = getattr(self, 'satfile', '/etc/enigma2/satellites.xml')
            bak = '/etc/enigma2/satellites.xml.' + str(int(time.time()))
            if os.path.exists(src):
                try:
                    os.rename(src, bak)
                except:
                    pass

            # Write new file
            if PY3:
                tree.write(src, encoding='utf-8', xml_declaration=True)
            else:
                tree.write(src, encoding='UTF-8', xml_declaration=True)

            # Update nimmanager
            if not self.updateSatList:
                try:
                    nimmanager.satList = []
                    nimmanager.cablesList = []
                    nimmanager.terrestrialsList = []
                    nimmanager.readTransponders()
                except:
                    pass

            return True

        except Exception as e:
            print("[SatXmlEditScreen] writeSatellites error:", str(e))
            return False

    def addSatellite(self):
        # Open Add Satellite directly (no clone dialog).
        # Note: the old menu code remains below and is kept intact, but is not executed due to return.
        try:
            self.addNewSat = None
            self.session.openWithCallback(self.finishedSatAdd, SatEditor, self.satelliteslist)
            return
        except Exception as e:
            print('[SatXmlEditScreen] addSatellite direct open error:', str(e))

        text = _("Select action:")
        menu = [(_("Add new"), "new")]
        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is not None and cur_idx < len(self.satelliteslist):
            menu.append((_("Clone current"), "clone"))

        def addAction(choice):
            if choice:
                self.addNewSat = None
                if choice[1] == "new":
                    self.session.openWithCallback(self.finishedSatAdd, SatEditor, self.satelliteslist)
                elif choice[1] == "clone":
                    self.addNewSat = self.satelliteslist[cur_idx][1] if len(self.satelliteslist[cur_idx]) > 1 else []
                    self.session.openWithCallback(self.finishedSatAdd, SatEditor,
                                                  self.satelliteslist, self.satelliteslist[cur_idx][0], clone=True)

        self.session.openWithCallback(addAction, ChoiceBox, title=text, list=menu)

    def finishedSatAdd(self, result):
        if result is None:
            return

        if self.addNewSat is None:
            self.satelliteslist.append([result, []])
        else:
            self.satelliteslist.append([result, self.addNewSat])

        self.updateSatList = True
        self['list'].setEntries(self.satelliteslist)
        global need_update
        need_update = True

    def editTransponders(self):
        if not len(self.satelliteslist):
            return

        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None or cur_idx >= len(self.satelliteslist):
            return

        satellite = self.satelliteslist[cur_idx]
        transponders = satellite[1] if len(satellite) > 1 else []
        self.session.openWithCallback(self.finishedTranspondersEdit, TranspondersEditor,
                                      [satellite[0], transponders])

    def finishedTranspondersEdit(self, result):
        if result is None:
            return

        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None or cur_idx >= len(self.satelliteslist):
            return

        if len(self.satelliteslist[cur_idx]) > 1:
            self.satelliteslist[cur_idx][1] = result
        else:
            self.satelliteslist[cur_idx].append(result)

        global need_update
        need_update = True

    def editSatellite(self):
        if not len(self.satelliteslist):
            return

        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None or cur_idx >= len(self.satelliteslist):
            return

        self.session.openWithCallback(self.finishedSatEdit, SatEditor,
                                      self.satelliteslist, self.satelliteslist[cur_idx][0])

    def finishedSatEdit(self, result):
        if result is None:
            return

        cur_idx = self['list'].getSelectedIndex()
        if cur_idx is None or cur_idx >= len(self.satelliteslist):
            return

        pos = 0
        try:
            pos = int(float(self.satelliteslist[cur_idx][0].get('position', '0')))
        except:
            pass

        now_pos = 0
        try:
            now_pos = int(float(result.get('position', '0')))
        except:
            pass

        if pos != now_pos:
            self.updateSatList = True

        self.satelliteslist[cur_idx][0] = result
        self['list'].setEntries(self.satelliteslist)
        global need_update
        need_update = True

    def deleteSatellite(self):
        if len(self.satelliteslist):
            cur_idx = self['list'].getSelectedIndex()
            if cur_idx is None or cur_idx >= len(self.satelliteslist):
                return

            self.satelliteslist.pop(cur_idx)
            self['list'].setEntries(self.satelliteslist)
            global need_update
            self.updateSatList = True
            need_update = True

    def removeSatellite(self):
        if len(self.satelliteslist):
            cur_idx = self['list'].getSelectedIndex()
            if cur_idx is None or cur_idx >= len(self.satelliteslist):
                return

            satellite = safe_text(self.satelliteslist[cur_idx][0].get('name', 'Unknown'))
            cb_func = lambda ret: not ret or self.deleteSatellite()
            self.session.openWithCallback(cb_func, MessageBox,
                                          _('Remove satellite %s?') % satellite,
                                          MessageBox.TYPE_YESNO)

    # --- Sorting (restored like original mainfile.py) ---
    def compareColumn(self, a):
        # NOTE: This method used by sortColumn()
        try:
            col = self.row[self.currentSelectedColumn][0]
        except Exception:
            col = 'position'
        if col == 'name':
            try:
                return safe_text(a[0].get('name', ''))
            except Exception:
                return ''
        if col == 'position':
            try:
                return int(float(a[0].get('position', '0')))
            except Exception:
                return 0
        return 0

    def sortColumn(self):
        # Sort satellites strictly by numeric 'position' (restored from original mainfile.py)
        if len(self.satelliteslist) <= 2:
            return
        # toggle reverse each time (blue key)
        rev = False
        try:
            # keep using the same toggle slot if present
            rev = self.row[1][2]
        except Exception:
            pass

        def _pos_key(a):
            try:
                return int(float(a[0].get('position', '0')))
            except Exception:
                return 0

        self.satelliteslist.sort(key=_pos_key, reverse=rev)
        try:
            self.row[1][2] = not rev
        except Exception:
            pass
        self['list'].setEntries(self.satelliteslist)
        self.updateSelection()
        global need_update
        need_update = True

    def Exit(self):
        global need_update
        if need_update:
            def saveCallback(ret):
                if ret:
                    try:
                        src = "/etc/enigma2/satellites.xml"
                        bak = "/etc/enigma2/satellites.xml.bak"
                        if os.path.exists(bak):
                            try:
                                os.remove(bak)
                            except:
                                pass

                        success = self.writeSatellites()
                        if success:
                            print("[SatXmlEditScreen] File saved successfully")
                        else:
                            print("[SatXmlEditScreen] Error saving file")

                    except Exception as e:
                        print("[SatXmlEditScreen] Error in saveCallback:", str(e))

                self.cleansatellitesxml()
                need_update = False
                self.close()

            self.session.openWithCallback(
                saveCallback,
                MessageBox,
                _('Save new /etc/enigma2/satellites.xml? \n(This takes some seconds.)'),
                MessageBox.TYPE_YESNO,
                default=True
            )
        else:
            self.cleansatellitesxml()
            need_update = False
            self.close()

    def cleansatellitesxml(self):
        top = '/etc/enigma2/'
        try:
            for root, dirs, files in os.walk(top, topdown=False):
                for name in files:
                    if 'satellites.xml.' in name:
                        try:
                            os.remove(os.path.join(root, name))
                        except:
                            pass
        except:
            pass

    def isBlihdscanXML(self):
        top = '/tmp/'
        try:
            for root, dirs, files in os.walk(top, topdown=False):
                for name in files:
                    if 'blindscan' in name and '.xml' in name:
                        return os.path.join(root, name)
        except:
            pass
        return None

    def showSatelliteInfo(self):
        self.session.open(MessageBox,
                          _('Autor original code mfaraj57\nFurther development Dimitrij openPLi'),
                          MessageBox.TYPE_INFO)

    def blihdscanXML(self):
        self.addNewSat = None
        xml_file = self.isBlihdscanXML()
        if not xml_file:
            return

        text = _("Select action for blindscan.xml:")
        menu = [(_("Show blindscan.xml"), "show"), (_("Add in user satellites.xml"), "add")]

        def addAction(choice):
            if choice:
                if choice[1] == "show":
                    self.session.open(Console, _('Show blindscan.xml'), ["cat %s" % xml_file])
                elif choice[1] == "add":
                    blindscan_satelliteslist = self.readSatellites(xml_file, stop=False)
                    if blindscan_satelliteslist:
                        self.addNewSat = blindscan_satelliteslist[0][1] if len(blindscan_satelliteslist[0]) > 1 else {}
                        self.session.openWithCallback(self.finishedSatAdd, SatEditor,
                                                      self.satelliteslist,
                                                      blindscan_satelliteslist[0][0],
                                                      clone=True)

        self.session.openWithCallback(addAction, ChoiceBox, title=text, list=menu)

    def showHelp(self):
        pass