# -*- coding: utf-8 -*-
from __future__ import print_function, division, absolute_import

#created by iet5
import os
from time import time
import xml.etree.cElementTree
from sys import version_info

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console

from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.config import (
    config, ConfigFloat, ConfigInteger, ConfigSelection,
    ConfigText, ConfigYesNo, getConfigListEntry
)
from Components.ConfigList import ConfigListScreen
from Components.GUIComponent import GUIComponent
from Components.HTMLComponent import HTMLComponent
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.NimManager import nimmanager
from Components.Pixmap import Pixmap

from Tools.Directories import fileExists
from enigma import (
    eListbox, gFont, eListboxPythonMultiContent,
    RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER,
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP,
    eRect, eTimer, getDesktop
)

from . import _
PY3 = version_info[0] == 3

# --------- Plugin Path ---------
plugin_path = os.path.dirname(os.path.realpath(__file__))

# --------- Version from file ---------
version_file_path = "/usr/lib/enigma2/python/Plugins/SystemPlugins/TSsatEditor/version.txt"
try:
    with open(version_file_path, "r") as f:
        currversion = f.read().strip()
except Exception:
    currversion = "Unknown"

# Import all components from separate files
from .components import (
    FHD_Res, HD_Res, need_update, config,
    Transponder, TransponderList, Head, SatelliteList
)

# Import screens
from .satxmleditscreen import SatXmlEditScreen
from .sateditscreen import SatEditor
from .addnewsatscreen import AddNewSatScreen
from .transpondereditor import TransponderEditor
from .transponderseditor import TranspondersEditor

# Initialize config
config.misc.tssateditorT2MI = ConfigYesNo(False)

# This is the main entry point for the plugin
def main(session, **kwargs):
    """Main entry point for TSsatEditor"""
    try:
        from .satxmleditscreen import SatXmlEditScreen
        session.openWithCallback(lambda *args, **kwargs: None, SatXmlEditScreen)
    except Exception as e:
        from Screens.MessageBox import MessageBox
        session.open(MessageBox, "Failed to open Satellite.xml Editor.\n%s" % str(e), MessageBox.TYPE_ERROR)

def Plugins(**kwargs):
    """Plugin descriptor for TSsatEditor"""
    from Plugins.Plugin import PluginDescriptor
    desc = "Satellite.xml Editor"
    return [
        PluginDescriptor(
            name="TSsatEditor",
            description=desc,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]