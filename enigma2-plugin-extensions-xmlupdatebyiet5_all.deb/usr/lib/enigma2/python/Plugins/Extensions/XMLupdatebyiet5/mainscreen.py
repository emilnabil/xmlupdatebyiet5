# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

# plugin created by iet5

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, config
from Components.ProgressBar import ProgressBar

class XMLupdateByIet5Screen(Screen, ConfigListScreen):

    skin = """    <screen name="XMLupdateByIet5Screen" position="center,center" size="1320,800"
        flags="wfNoBorder" backgroundColor="#303030">

        <!-- Buttons Background: RED / GREEN / YELLOW / BLUE (same style as other screens) -->
        <ePixmap pixmap="skin_default/buttons/red.png"    position="40,50"   size="300,70" scale="stretch" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/green.png"  position="360,50"  size="300,70" scale="stretch" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/yellow.png" position="680,50"  size="300,70" scale="stretch" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/blue.png"   position="1000,50" size="300,70" scale="stretch" alphatest="on" />

        <!-- Buttons -->
        <widget name="key_red"    position="40,50"   size="300,70" font="Regular;32"
            halign="center" valign="center" transparent="1" backgroundColor="#9f1313"
            foregroundColor="white" zPosition="2" />
        <widget name="key_green"  position="360,50"  size="300,70" font="Regular;32"
            halign="center" valign="center" transparent="1" backgroundColor="#1f771f"
            foregroundColor="white" zPosition="2" />
        <widget name="key_yellow" position="680,50"  size="300,70" font="Regular;32"
            halign="center" valign="center" transparent="1" backgroundColor="#a08500"
            foregroundColor="black" zPosition="2" />
        <widget name="key_blue"   position="1000,50" size="300,70" font="Regular;32"
            halign="center" valign="center" transparent="1" backgroundColor="#0033aa"
            foregroundColor="white" zPosition="2" />

        <!-- Header -->
        <widget name="title_left"  position="10,0" size="900,40"  font="Regular;32"
            halign="left" valign="center" transparent="1" foregroundColor="white" />
        <widget name="title_right" position="910,0" size="400,40" font="Regular;32"
            halign="right" valign="center" transparent="1" foregroundColor="white" />

        <!-- Config area -->
        <widget name="config" position="10,125" size="1300,490" itemHeight="55"
            font="Regular;32" enableWrapAround="1" scrollbarMode="showOnDemand" />

        <!-- Divider -->
        <ePixmap pixmap="skin_default/div-h.png" position="10,615" size="1300,2" />

        <!-- Progress -->
        <widget name="progress" position="10,630" size="1300,18" />
        <widget name="progress_text" position="10,652" size="1300,28" font="Regular;26"
            halign="center" foregroundColor="white" />

        <!-- Footer -->
        <widget name="footer" position="10,690" size="1300,40" font="Regular;26"
            halign="center" valign="center" foregroundColor="#FFD700" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        # import runtime helpers from plugin.py (avoid circular import at top)
        from . import plugin as core
        self.core = core

        self._last_download_ok = False

        self["title_left"] = Label("XMLupdate by iet5")
        self["title_right"] = Label(self.core.read_version())

        # Buttons order requested:
        # Red = Exit/Cancel (left)
        # Green = Save
        # Yellow = Satellite.xml Edit
        # Blue = Download
        self["key_red"] = Label("Exit")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Satellite.xml Edit")
        self["key_blue"] = Label("Download")

        self["footer"] = Label("Ready.")

        self["progress"] = ProgressBar()
        self["progress"].setValue(0)
        self["progress_text"] = Label("0%")

        ConfigListScreen.__init__(self, [], session=session)
        self.build_list()

        self["actions"] = ActionMap(
            ["ColorActions", "OkCancelActions"],
            {
                "red": self.close,
                "green": self.save_settings,
                "yellow": self.open_sat_editor,
                "blue": self.do_download,
                "cancel": self.close,
            },
            -1
        )

    def build_list(self):
        p = config.plugins.XMLupdatebyiet5
        lst = []
        lst.append(getConfigListEntry("Save mode", p.save_mode))
        if p.save_mode.value == "custom":
            lst.append(getConfigListEntry("Path where to save", p.custom_path))

        lst.append(getConfigListEntry("Download + backup satellites.xml", p.do_sat))
        lst.append(getConfigListEntry("Download + backup terrestrial.xml", p.do_ter))
        lst.append(getConfigListEntry("Download + backup cables.xml", p.do_cab))
        lst.append(getConfigListEntry("Restart GUI after update", p.restart_gui_after_update))

        self["config"].list = lst

    # ---------- YELLOW: open satellites.xml editor ----------
    def open_sat_editor(self):
        try:
            from .satxmleditscreen import SatXmlEditScreen
            self.session.openWithCallback(lambda *args, **kwargs: None, SatXmlEditScreen)
        except Exception as e:
            self.session.open(MessageBox, "Failed to open Satellite.xml Editor.\n%s" % str(e), MessageBox.TYPE_ERROR)

    # ---------- Save only (GREEN) ----------
    def save_settings(self):
        try:
            config.plugins.XMLupdatebyiet5.save()
            config.save()
            self["footer"].setText("Settings saved.")
            self.core.log_line("Settings saved.")
            self.session.open(MessageBox, "Settings saved successfully.", MessageBox.TYPE_INFO)
        except Exception as e:
            self["footer"].setText("Failed to save settings.")
            self.core.log_line("Failed to save settings: %s" % str(e))
            self.session.open(MessageBox, "Failed to save settings.", MessageBox.TYPE_ERROR)

    # ---------- Restart confirmation ----------
    def _ask_restart_gui(self):
        if not self.core.can_restart_gui():
            self.session.open(MessageBox, "Restart GUI is not supported on this image.", MessageBox.TYPE_ERROR)
            return

        self.session.openWithCallback(
            self._on_restart_answer,
            MessageBox,
            "Restart GUI now?",
            MessageBox.TYPE_YESNO
        )

    def _on_restart_answer(self, answer):
        if answer:
            self.core.log_line("Restart GUI confirmed by user.")
            self.core.do_restart_gui(self.session)
        else:
            self.core.log_line("Restart GUI cancelled by user.")
            self["footer"].setText("Restart cancelled.")

    # ---------- Result popup then restart ----------
    def _show_download_result_then_restart(self, result):
        self._last_download_ok = bool(result.get("all_ok", False))

        downloaded_files = int(result.get("downloaded_files", 0))
        ok_copies = int(result.get("ok_copies", 0))
        fail_copies = int(result.get("fail_copies", 0))
        targets = result.get("targets", []) or []
        targets_txt = ", ".join(targets)

        if self._last_download_ok:
            self["footer"].setText("Download completed successfully.")
            msg = (
                "Download completed successfully.\n"
                "Downloaded files: %d\n"
                "Saved copies: %d\n"
                "Failed copies: %d\n"
                "Saved to: %s"
            ) % (downloaded_files, ok_copies, fail_copies, targets_txt)
            mtype = MessageBox.TYPE_INFO
        else:
            self["footer"].setText("Download completed with errors.")
            msg = (
                "Download completed with errors.\n"
                "Downloaded files: %d\n"
                "Saved copies: %d\n"
                "Failed copies: %d\n"
                "Saved to: %s\n"
                "Log: %s"
            ) % (downloaded_files, ok_copies, fail_copies, targets_txt, self.core.LOG_FILE)
            mtype = MessageBox.TYPE_WARNING

        # show for 2 seconds then ask restart (if enabled and all ok)
        self.session.openWithCallback(
            self._after_result_popup,
            MessageBox,
            msg,
            mtype,
            timeout=2
        )

    def _after_result_popup(self, *args, **kwargs):
        if self._last_download_ok and config.plugins.XMLupdatebyiet5.restart_gui_after_update.value:
            self._ask_restart_gui()

    # ---------- Download only (BLUE) ----------
    def do_download(self):
        # UI reset
        self["footer"].setText("Starting download...")
        self["progress"].setValue(0)
        self["progress_text"].setText("0%")

        # If nothing selected -> show message
        if not self.core.get_selected_files():
            self.session.open(MessageBox, "Nothing selected to download.", MessageBox.TYPE_INFO)
            self["footer"].setText("Nothing selected.")
            self.core.log_line("Download requested but nothing selected.")
            return

        def progress_cb(pct):
            try:
                if pct < 0:
                    pct = 0
                if pct > 100:
                    pct = 100
                self["progress"].setValue(pct)
                self["progress_text"].setText("%d%%" % pct)
            except Exception:
                pass

        def status_cb(text):
            try:
                self["footer"].setText(text)
            except Exception:
                pass

        result = self.core.run_download(progress_cb=progress_cb, status_cb=status_cb)
        self._show_download_result_then_restart(result)
