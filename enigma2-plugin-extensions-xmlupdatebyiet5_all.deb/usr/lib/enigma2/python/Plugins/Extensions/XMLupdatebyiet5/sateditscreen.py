# -*- coding: utf-8 -*-
from __future__ import print_function, division

# Created by iet5
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.config import (
    config, ConfigFloat, ConfigInteger, ConfigSelection,
    ConfigText, ConfigYesNo, getConfigListEntry
)
from Components.ConfigList import ConfigListScreen

from .components import FHD_Res, HD_Res, _
from .components import need_update
# safe_text is used to normalize text types across Python2/3 and E2 builds
from .components import safe_text


class SatEditor(Screen, ConfigListScreen):
    flagNetworkScan = 1
    flagUseBAT = 2
    flagUseONIT = 4

    # FHD only. Layout is based on the old (working) mainfile.py to prevent
    # row text from sticking together on some OpenATV-based skins.
    # NOTE: We keep the NEW button background images (skin_default/buttons).
    skin = """        <screen name="SatEditor" position="center,center" size="1320,800" title="Edit satellite" >
            <ePixmap pixmap="skin_default/buttons/red.png" position="40,0" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/green.png" position="360,0" size="300,70" scale="stretch" alphatest="on" />

            <widget name="key_red" position="40,0" zPosition="1" size="300,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
            <widget name="key_green" position="360,0" zPosition="1" size="300,70" font="Regular;32"
                halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />

            <widget name="config" position="10,125" size="1300,655" font="Regular;30" itemHeight="50"
                scrollbarMode="showOnDemand" />
        </screen>"""

    def __init__(self, session, satelliteslist=None, satelliteData=None, clone=False):
        self.skin = SatEditor.skin
        Screen.__init__(self, session)
        self.satelliteData = satelliteData
        self.satelliteslist = satelliteslist
        self.firstSatellitePosition = 0
        self.clone = clone
        self.satelliteOrientation = 'east'
        if self.satelliteData is not None:
            self.satelliteName = safe_text(self.satelliteData.get('name', 'unknown satellite name'))
            if self.clone:
                self.satelliteName += ' (copy)'
            satellitePosition = int(float(self.satelliteData.get('position', '0')))
            self.firstSatellitePosition = satellitePosition
            if satellitePosition < 0:
                self.satelliteOrientation = 'west'
            satellitePosition = abs(satellitePosition)
            self.satellitePosition = [satellitePosition // 10, satellitePosition % 10]
            self.satelliteFlags = int(float(self.satelliteData.get('flags', '1')))
        else:
            self.satelliteName = 'new satellite'
            self.satellitePosition = [0, 0]
            self.satelliteFlags = 1
        self.createConfig()
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'cancel': self.cancel,
         'ok': self.okExit,
         'red': self.cancel,
         'green': self.okExit}, -1)
        self['key_red'] = Button(_("Close"))
        self['key_green'] = Button(_('OK'))
        # Yellow/Blue keys are visually present (skin compatibility) but disabled by actions.
        self['key_yellow'] = Button('')
        self['key_blue'] = Button('')
        self.list = []
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.layoutFinished)
        self.createSetup()

    def layoutFinished(self):
        text = _('Edit ')
        if self.clone: text = _('Clone current ')
        if self.satelliteData is None: text = _('Add ')
        self.setTitle(text + self.satelliteName)

        # --- Per-screen spacing fixes (do NOT share global settings) ---
        # Some skins render ConfigList rows too close together unless itemHeight/font
        # are applied after the screen is laid out.
        try:
            from enigma import gFont
            if hasattr(self['config'], 'l'):
                self['config'].l.setItemHeight(40)
                try:
                    self['config'].l.setFont(0, gFont('Regular', 26))
                except TypeError:
                    try:
                        self['config'].l.setFont(gFont('Regular', 26))
                    except Exception:
                        pass
        except Exception:
            pass

    def createConfig(self):
        self.configSatelliteName = ConfigText(default=self.satelliteName, visible_width=50, fixed_size=False)
        self.configSatelliteName.setUseableChars(u"0,?!&@=*'+\()$~% 1.:;/-_#abc2ABCdef3DEFghi4GHIjkl5JKLmno6MNOpqrs7PQRStuv8TUVwxyz9WXYZ")
        self.configSatellitePosition = ConfigFloat(default=self.satellitePosition, limits=[(0, 180), (0, 9)])
        self.configSatelliteOrientation = ConfigSelection([('east', 'East'), ('west', 'West')], self.satelliteOrientation)
        options = self.satelliteFlags in (1, 3, 5, 7) and True or False
        self.configSatelliteFlagNetworkScan = ConfigYesNo(default=options)
        options = self.satelliteFlags in (2, 3, 6, 7) and True or False
        self.configSatelliteFlagUseBAT = ConfigYesNo(default=options)
        options = self.satelliteFlags in (4, 5, 6, 7) and True or False
        self.configSatelliteFlagUseONIT = ConfigYesNo(default=options)

    def createSetup(self):
        self.list = []
        self.list.append(getConfigListEntry(_('Name'), self.configSatelliteName))
        self.list.append(getConfigListEntry(_('Position'), self.configSatellitePosition))
        self.list.append(getConfigListEntry(_('Orientation'), self.configSatelliteOrientation))
        self.list.append(getConfigListEntry(_('Network scan'), self.configSatelliteFlagNetworkScan))
        self.list.append(getConfigListEntry(_('BAT'), self.configSatelliteFlagUseBAT))
        self.list.append(getConfigListEntry(_('ONIT'), self.configSatelliteFlagUseONIT))
        self['config'].list = self.list
        self['config'].l.setList(self.list)

    def cancel(self):
        self.close(None)

    def okExit(self):
        satelliteFlags = 0
        if self.configSatelliteFlagNetworkScan.value:
            satelliteFlags += self.flagNetworkScan
        if self.configSatelliteFlagUseBAT.value:
            satelliteFlags += self.flagUseBAT
        if self.configSatelliteFlagUseONIT.value:
            satelliteFlags += self.flagUseONIT
        satellitePosition = self.configSatellitePosition.value[0] * 10 + self.configSatellitePosition.value[1]
        if self.configSatelliteOrientation.value == 'west':
            satellitePosition = -satellitePosition
        if satellitePosition == 0:
            self.session.open(MessageBox, _('Sorry, you can not use prime meridian.'), MessageBox.TYPE_ERROR)
            return
        if self.satelliteslist:
            exception = not self.clone and self.satelliteData
            for sat in self.satelliteslist:
                pos = int(float(sat[0].get('position', '0')))
                if satellitePosition == pos:
                    if exception:
                        if self.firstSatellitePosition != 0 and pos == self.firstSatellitePosition:
                            continue
                    self.session.open(MessageBox, _('This position number is busy.\nSelect another position.'), MessageBox.TYPE_ERROR)
                    return
        satelliteData = {'name': self.configSatelliteName.value, 'flags': str(satelliteFlags), 'position': str(satellitePosition)}
        global need_update
        need_update = True
        self.close(satelliteData)